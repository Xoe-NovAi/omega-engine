# Legacy Infrastructure Evidence — HISTORICAL / SUPERSEDED

**HISTORICAL · SUPERSEDED · NON-AUTHORITATIVE · NON-EXECUTABLE · DRAFT · UNSIGNED · NOT PART OF THE SEALED PACKAGE**

These directories (`attestation/`, `c6-contract/`, `omega-hub-patches/`, `redis/`,
`tailscale/`, `spire/`) are dated **2026-09-22** and predate the sealed
`exchange/n0-to-n1/` package (2026-09-25) and the decisions ratified after them.
They have been quarantined here so they can no longer be mistaken for current authority.

**Not part of the sealed package.** They are excluded from the sealed package's
`MANIFEST.yaml` and `SHA256SUMS`. Nothing in this directory is executable authority.

## Contradiction table — exact supersessions

| Legacy claim (2026-09-22) | Superseded by |
|---|---|
| Hub tool count 92 (was 93) | 66 tools after pruning |
| Hub health `version: 2.2.0` | `1.6.0-alpha.1` on all four SSOT surfaces |
| NFSv4.2 bidirectional exchange operational / required (C6 Art.5, ACL 2049/20048/662/32803) | D-FED-01: NFS demoted; git bundle + minisign is the authoritative release path; sealed package states no cross-node NFS/SSH |
| Redis maxmemory 64mb + Node 1 connects to `OMEGA_REDIS_HOST=100.123.51.67:6379` while config also says `bind 127.0.0.1` | D-FED-02: loopback-only, bounded 512mb, non-authoritative, N0-local only (the legacy cross-node client directive is unsatisfiable against a loopback bind and must not be followed) |
| ACL grants bidirectional NFS + SSH | Not ratified; ACL is PROPOSED only; sealed package forbids cross-node NFS/SSH |
| Attestation `Status: SIGNED` | Text footer only — a `SIGNED` string is not a signature; no detached signature or trust root exists; C6/N0-04 remains OPEN |
| C6 contract v0.1 | DRAFT, all ratification boxes unchecked; Article 5 (NFS) conflicts with D-FED-01 |
| `spire/` | Empty; SPIFFE/SPIRE explicitly deferred until git-bundle federation is proven |
| Patches doc `oracle_list_pillar_keepers` note | Still valid as historical N1 cache-hygiene note |

## Handling rules

These files remain useful as **forensic history** and must not be **deleted**,
**executed**, or **cited as current authority**.

**Reading order:** `../README_FIRST.md` first (the sealed package entrypoint).
This directory is **optional background only** — never a substitute for the sealed
package's `README_FIRST.md`, `MANIFEST.yaml`, `SHA256SUMS`, or `07_open_gates/` notes.

- `spire/` is empty and explicitly **deferred** until git-bundle federation is proven.
- `c6-contract/` is DRAFT/UNSIGNED; C6/N0-04 remains OPEN in `exchange/n0-to-n1/07_open_gates/`.
- `attestation/` carries a text footer, not a cryptographic signature.
- `redis/` and `tailscale/` describe superseded topology; the sealed package uses the
  exact HTTPS `/mcp` endpoint and forbids cross-node NFS/SSH.

*⬡ OMEGA ⬡ GROKSTER ⬡ LEGACY-QUARANTINE ⬡ HISTORICAL-NON-AUTHORITATIVE ⬡ 2026-09-25*
