# 🔱 Antigravity IDE — Review Request: Sealed N0→N1 Handoff Package

**Document ID:** `FED-ANTIGRAVITY-REVIEW-REQUEST-20260925-01`
**Prepared for:** Antigravity IDE (frontier-model independent review)
**Prepared by:** MaKaLi Fusion / Omega Engine governance layer
**Date:** 2026-09-25
**Review mode:** Independent adversarial review of a package already marked SHIP FOR PHYSICAL QUARANTINE
**Supersedes:** `docs/federation/ANTIGRAVITY_REVIEW_BRIEFING_20260924.md` (facts in that briefing have been superseded — see §2)

**Handling:** Internal engineering review. No credentials, cookies, browser material, private personal data, live databases, raw Tailscale state, or unapproved personal material may be included in the review package.

---

## 1. What we are asking you to review

Not a design document. A **sealed, manifested, checksummed artifact package** that has already passed:

- Grokster package assembly + reseal (41 manifest entries, 42 root SHA entries);
- Carmack independent audit #1 → **DO NOT SHIP**;
- two remediation rounds;
- Carmack final delta audit → **SHIP FOR PHYSICAL QUARANTINE**;
- a fresh-eyes documentation-economy audit (overdocumentation pass);
- a final status-consistency reseal + Carmack confirmation.

**Package location:**

```text
data/federation/usb-payload/exchange/n0-to-n1/
```

We are asking whether that verdict is *correct* — and whether anything inside the package would cause harm, drift, or false belief once it is copied by hand onto a laptop beside Node 1.

This is a **final look before physical movement**, not a redesign invitation.

---

## 2. Corrected facts — do not use the 20260924 briefing's numbers

The prior briefing recorded pre-remediation measurements. Several are now **historical only**. Authoritative current values:

| Fact | Current (authoritative) | Historical only (do not treat as live) |
|---|---|---|
| Active checkout | `fa9c4edc68fe0f23a052e941f88d573f47c6c249` | `75bde939` (WAD-contract baseline only) |
| Branch | `release/debut-v1.6.0` | — |
| Operative version | `1.6.0-alpha.1` on all four surfaces: pyproject, `omega.__version__`, Hub `/health`, MCP `serverInfo` | Hub `2.2.0`, MCP `1.30.0`, pyproject `1.2.0` |
| Canonical endpoint | `https://n0.tail51f14a.ts.net:8016/mcp` (exact, no trailing slash) | bare `0.0.0.0:8016` LAN exposure |
| MCP tool count | 66 | 92 (pre-prune) |
| Hub bind | `127.0.0.1` behind Tailscale Serve HTTPS | `0.0.0.0:8016` |

If you cite a value, cite it from the package, not from the old briefing.

---

## 3. Current measured state of the package

- 43 physical files, ~234 KB total.
- Root manifest: 41/41 path/size/hash PASS. Root SHA ledger: 42/42 PASS.
- Nested `doom_guy_transfer/` manifest 3/3, SHA 4/4 PASS.
- YAML/JSON parse: 13/13 PASS.
- M35 secret scan: 41 files, **0 violations**.
- Raw Node 0 absolute paths: **0**. Trailing `/mcp/`: **0**. Blind `sed -i` guidance: **0**.
- WAD loader tests: **31 PASS**. Both PWAD negative fixtures: **expected exit 1** (negative regression, *not* compatibility pass).

### Package map

| Path | Purpose |
|---|---|
| `01_engine_truth/` | Active checkout authority + version SSOT |
| `02_wad_loader_contract/` | Current-loader contract + negative PWAD fixtures |
| `03_governance/` | Identity ontology, Persona WAD proposal, soul audit, inactive dialectic protocol |
| `04_flynn_taggart_bootstrap/` | Fresh-identity requirements (lineage-only) |
| `05_node1_ingestion/` | MCP config, plugin install, verification checklist, historical reports |
| `06_archangel_brief/` | Mandates + Bastion/Vanguard topology |
| `07_open_gates/` | C6/N0-04 gate + remediation status |
| `08_library_curation_research/` | Roc Racoon's 8-file library-curation research bundle (~95 KB) |
| `doom_guy_transfer/` | Read-only lineage wrappers; explicitly non-installable |

---

## 4. Governance state that the package encodes

These are ratified invariants, not proposals. Flag them only if you believe one is *architecturally wrong* — not merely unusual.

- **Node 0 = Bastion** (canonical source, release authority, hub, provenance). **Node 1 = Vanguard** (ANAi/WAD dev, continuity, local inference, library-curation owner). Neither node is subordinate.
- **D-FED-01:** `git bundle` + minisign is the authoritative release path; NFS demoted.
- **D-FED-02:** Redis loopback-only, bounded 512 MB, non-authoritative cache.
- **D-FED-03 RETIRED:** entities are sovereign *and* may collaborate. Delegation requires an explicit contract (`OD-IDENTITY-006`).
- **Doom Guy-N0** is sovereign, invariant, continuous on Node 0. `doom_guy_transfer/` is lineage evidence only — never an install payload.
- **Flynn Taggart** is a *new* sovereign entity born on Node 1: fresh EIS, `continuation_of: null`, lineage-only seed. Not a clone or rename.
- **Build and Slot are not agents.** No agent souls for them. **Scribe is a distinct entity/soul**, counted separately. One Makali, not two.
- **Soul-memory separation:** a soul is a portable identity temple (orientation, values, boundaries, voice). Granular memory belongs to MemPalace/sqlite-vec; transcripts to OpenCode SQLite. Bug-fix/config content must never enter `soul.yaml`.
- **Transport:** physical USB = personally controlled quarantine (Architect-approved). Network bridge = HTTPS MCP only. No cross-node NFS/SSH. Tailscale reachability is *not* application authentication.
- **Integrity ≠ trust:** SHA ledgers prove byte integrity only.

---

## 5. The one live trust gate

**C6/N0-04 is OPEN.** The package has no ratified C6 contract, publisher key identity, publisher trust root, detached signature, or tamper-verification bundle.

Consequently the package claims exactly this and nothing more:

```text
PHYSICAL USB QUARANTINE TRANSFER: APPROVED (Architect, personally controlled)
FINAL AUTHENTICATED TRANSFER: NOT CLAIMED / BLOCKED
```

**Primary question for you:** Is the Architect's physical-quarantine disposition a sufficient interim control for a hand-to-hand USB move into Node 1 quarantine — or is there a concrete failure mode that this disposition does not cover and that should block movement?

Assume the transfer is physically controlled (same room, same operator, no third-party handling). Do not re-argue that a USB stick is inherently untrustworthy; argue about what happens *after* it lands.

---

## 6. Specific review questions

Distinguish **fatal blocker** / **high-risk caveat** / **optional opportunity** in every answer.

### A. Package correctness
1. Does any file inside the package contradict another file on status, version, checkout, endpoint, or identity rules? (We found and fixed one such class — stale "awaiting Carmack" status. Look for others.)
2. Is the reader path `README_FIRST → 01_engine_truth → 02_wad_loader_contract → 04_flynn_taggart_bootstrap → 05_node1_ingestion → 07_open_gates → 08_library_curation_research` sufficient for a cold operator on Node 1?
3. Is the negative PWAD fixture (`exit 1`) likely to be misread as a failure by an automated or hurried operator? What is the minimal fix?

### B. Documentation economy
4. The package carries historical reports (`N1_READINESS_REPORT`, `PLUGIN_AUDIT_REPORT`), a future proposal (`PERSONA_WAD_ARCHITECTURE`), an inactive protocol, and a ~95 KB research bundle. We marked these non-operative rather than removing them. Is that the right call for a *physical* handoff, or should the USB carry only the operational minimum and leave research in the source repo?
5. Where is the highest remaining risk of a reader mistaking historical/proposal material for current authority?

### C. Trust and transfer
6. Beyond C6/N0-04, what is the smallest detached-signature + trust-root design that would let us honestly claim *authenticated* transfer for a two-node system? (Deferred work — we want the design, not an implementation.)
7. What post-arrival verification must run on Node 1 *before* anything in this package is treated as authoritative? Give the exact ordered sequence.

### D. Identity and sovereignty
8. Is the Flynn Taggart fresh-identity contract (`fresh_eis: true`, `continuation_of: null`, lineage-only, separate namespace) sufficient to prevent accidental Doom Guy duplication on Node 1? What is the most likely way it gets violated anyway?
9. Is the `doom_guy_transfer/` read-only/non-installable framing robust against a future agent that reads it as an install instruction?

### E. Architecture (Bastion/Vanguard)
10. Is the Bastion/Vanguard role split sustainable, or does it create permanent fork debt for `src/omega/`?
11. Is deferring SPIFFE/SPIRE, 384→768-D embedding migration, signed dialectic event-chains, chaos tests, and C6 ratification until Git-bundle federation is proven the correct sequencing? Name anything in that deferred list you would pull forward, and why.

### F. Library curation (Roc's new bundle)
12. Node 1 is handed a 20-item manifest-only pilot boundary before any autonomous crawl or vector federation. Is that boundary enforceable in practice, and what is the most likely way it gets crossed accidentally?
13. The bundle preserves nine unresolved caveats, including a Nomic-vs-Qwen 768-D embedding mismatch, unproven rights/robots enforcement in the scraper path, and CAS possibly not preserving raw HTTP responses. Are any of these *understated* to the point of being dangerous?
14. Does handing Node 1 curation ownership (Open Library, Internet Archive, Gutenberg, HathiTrust, Crossref, OpenAlex, arXiv, PubMed, etc.) create a rights/provenance exposure that the package's framing does not adequately contain?

---

## 7. Required output format

1. Executive verdict: **SHIP** / **SHIP WITH CORRECTIONS** / **DO NOT SHIP** for physical quarantine.
2. Fatal blockers (if any), each with the exact file path and line.
3. High-risk caveats.
4. Hidden opportunities.
5. Answers to §6, each tagged blocker / caveat / opportunity.
6. Ordered Node 1 post-arrival verification sequence.
7. Minimal authenticated-transfer design (signature + trust root) for two nodes.
8. Claims you believe should be *removed* from the package because they are not evidenced.
9. Assumptions requiring explicit operator ratification.

## 8. Anti-patterns — do not do these

Do not silently assume:

- a proposal is a decision;
- a checksum proves provenance;
- a reachable port is authenticated;
- a `SIGNED` string is a signature;
- a WAD filename establishes identity;
- a model route establishes persistent identity;
- the 66-tool surface is a frozen public API;
- a green transport diagnostic means the application layer is secure;
- physical quarantine approval equals final authenticated transfer;
- research attribution equals implementation.

Optimize for sovereignty, recoverability, verifiability, privacy, and long-term maintainability — not feature count.

---

*⬡ OMEGA ⬡ MAKALI_FUSION ⬡ ANTIGRAVITY-REVIEW-REQUEST ⬡ 2026-09-25 ⬡ PUBLIC-DEBUT-01*
