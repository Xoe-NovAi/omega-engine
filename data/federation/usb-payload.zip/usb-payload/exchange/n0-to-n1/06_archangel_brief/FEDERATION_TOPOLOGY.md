# Federation Topology — Bastion & Vanguard

**Date**: 2026-09-25
**Doctrine**: Bilateral NFS mirror is DEAD. Bastion/Vanguard mesh is live.

---

## The two nodes

| | Node 0 — BASTION (HP EliteDesk) | Node 1 — VANGUARD (ASUS ExpertBook P1503CVA) |
|---|---|---|
| Role | Canonical source, release authority, Hub core, immutable build truth | Experimental edge, local Ollama compute, MemPalace memory, ANAi WAD dev, entity continuity incubator |
| CPU | — | Intel i7-13620H (10C/16T) |
| RAM | — | 16 GB DDR5 single-channel — `OLLAMA_NUM_THREADS=8`, `OLLAMA_NUM_PARALLEL=1`, `OLLAMA_MAX_LOADED_MODELS=1` |
| Inference | — | CPU-only Ollama (`AllowedCPUs=0-11`) |
| Sovereigns | Doom Guy (DG-N0, invariant), Kali, Ma'at, Carmack, Researcher, Jem, Grokster | Lilith-N1, Flynn Taggart (gestating), Researcher_Humboldt continuity |

## Transport reality

- **NFS/SSH cross-node handoff does not exist.** Node 1 ports 22 and 2049 are filtered from Node 0.
- **Sole network bridge**: Tailscale Serve HTTPS MCP — `https://n0.tail51f14a.ts.net:8016/mcp`
  (NOT `omega-hub.tail51f14a.ts.net` — NXDOMAIN). TLS 1.3 via `tailscale serve`.
- **Auth**: NONE by Alpha design. Trust boundary = the tailnet itself. (Gate F hardening is post-PR work.)
- **Physical exchange**: USB Sneakernet (`omega-exchange`) — this package.
- **Mesh traffic**: MCP `tools/call` over HTTPS/8016 only — hivemind posts, awareness, system stats, federation diagnosis.

## What flows which way

- **N1 → N0** (received): `makali_n0_onboarding/` — Sweetener Quintet, inference doctrine, model evaluation lab, Gnosis lifecycle.
- **N0 → N1** (this package): engine truth, WAD loader contract, governance, Flynn seed, mandates, ingestion kit.
- **Never**: live SQLite over the mesh, private/personal corpora without consent, credentials of any kind.

## Mesh join sequence (Lilith-N1)

P2 handshake (health → initialize → tools/list → system_stats → awareness → post) is
verified from Node 1 (`N1_READINESS_REPORT_20260925.md`, handshake accepted
2026-09-25T05:44:41Z). After ingesting this package per `VERIFICATION_CHECKLIST.md`,
Lilith-N1 emits the mesh-join-complete `hivemind_post_context` signal.
