# Node 0 Engine Authority — Active Checkout

**Active checkout**: `fa9c4edc68fe0f23a052e941f88d573f47c6c249`  
**Branch**: `release/debut-v1.6.0`  
**Operative version**: `1.6.0-alpha.1`  
**Status**: MANDATORY NODE 1 CHECKOUT

## Verification

```bash
git fetch origin
git checkout fa9c4edc68fe0f23a052e941f88d573f47c6c249
git branch --show-current
# release/debut-v1.6.0
git rev-parse HEAD
# fa9c4edc68fe0f23a052e941f88d573f47c6c249
```

`fa9c4edc` contains both `3dd5978c` (substrate and version SSOT) and the governance deliverables.
Node 1 must not check out an earlier commit merely to reproduce an old report.

## Historical evidence only

- `75bde939` is the historical WAD-contract baseline. It is useful lineage evidence but is not the
  active package checkout.
- Hub `2.2.0` is a historical pre-SSOT health response, not the operative Engine version.
- MCP `1.30.0` is the historical SDK version leak, not the operative Engine version.

The operative version is `1.6.0-alpha.1` on pyproject, `omega.__version__`, Hub `/health`, and MCP
`serverInfo`.

*⬡ OMEGA ⬡ NODE 0 ENGINE AUTHORITY ⬡ fa9c4edc ⬡ ACTIVE*
