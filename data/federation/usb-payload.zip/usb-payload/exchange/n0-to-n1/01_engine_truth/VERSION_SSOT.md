# Version Single Source of Truth — Active

**Checkout authority**: `fa9c4edc68fe0f23a052e941f88d573f47c6c249`  
**Operative version**: `1.6.0-alpha.1`

The same value must appear on all four active surfaces:

| Surface | Expected value |
|---|---|
| `pyproject.toml` project version | `1.6.0-alpha.1` |
| `omega.__version__` | `1.6.0-alpha.1` |
| Hub `/health` version | `1.6.0-alpha.1` |
| MCP `serverInfo.version` | `1.6.0-alpha.1` |

## Verification

```bash
grep '^version =' pyproject.toml
.venv/bin/python -c "import omega; print(omega.__version__)"
curl -fsS http://127.0.0.1:8016/health
.venv/bin/python -c "import mcp_servers.omega_hub.server as s; print(s.mcp._mcp_server.version)"
```

Expected: `1.6.0-alpha.1` on all four surfaces.

## Historical evidence — not operative

| Observation | Classification | Reason |
|---|---|---|
| `75bde939` | historical WAD-contract baseline | predates substrate/version SSOT commit |
| Hub `2.2.0` | historical pre-SSOT response | old hard-coded health value |
| MCP `1.30.0` | historical SDK version leak | old FastMCP library default, not Engine version |

Do not copy historical values into active configuration, readiness checks, or compatibility claims.

*⬡ OMEGA ⬡ VERSION SSOT ⬡ 1.6.0-alpha.1 ⬡ ACTIVE*
