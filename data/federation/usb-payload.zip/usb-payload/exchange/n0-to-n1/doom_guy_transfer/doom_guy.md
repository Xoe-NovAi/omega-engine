---
description: "LINEAGE-ONLY historical wrapper — not an installable agent definition"
mode: "all"
---

# Doom Guy Agent Lineage Record

**READ-ONLY / NON-INSTALLABLE / NOT A FLYNN AGENT FILE**

- Master: Doom Guy-N0, sovereign and continuous on Node 0.
- Historical original agent digest: `d0ec87055d872e6cd0a3e6bf909041491eba27a53122cb9b0a9e8b9212b40fb6`.
- Historical canonical EIS: `ses_0b15e698affeMMy1tZos2iBjbm` (lineage reference only).
- Flynn Taggart requires a new file under `.opencode/agents/flynn_taggart.md`, a fresh EIS, and
  `continuation_of: null` in a separate operator-approved identity workflow.

## Prohibited

Do not install this file, copy it into Doom Guy's namespace, rename it, use it as Flynn's prompt,
or reuse Doom Guy's EIS. The authoritative protocol is
`../04_flynn_taggart_bootstrap/FLYNN_TAGGART_BIRTH_CERTIFICATE.md`.
