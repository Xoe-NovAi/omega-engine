# Node 1 Ingestion — Verification Checklist

**Package**: N0 → N1 reciprocal handoff, 2026-09-25
**Engine HEAD**: `fa9c4edc` (`release/debut-v1.6.0`, pushed to origin)
**Version**: `1.6.0-alpha.1` on all four surfaces
**Hub**: `https://n0.tail51f14a.ts.net:8016/mcp` (Tailscale Serve HTTPS, unauthenticated Alpha)

Run top to bottom. Stop and report on the first failure (M23 — no synthesis over breakage).

---

## A. Quarantine extraction (USB `omega-exchange`)

- [ ] Mount USB read-only; copy `n0-to-n1/` to a quarantine staging dir (never into the live checkout)
- [ ] `sha256sum -c SHA256SUMS` → every file `OK`, zero failures
- [ ] Spot-check `MANIFEST.yaml` package id `MAKALI-N0-HANDOFF-2026-09-25` and engine HEAD `fa9c4edc`
- [ ] Confirm zero forbidden absolute host paths and review the exact file list in `MANIFEST.yaml`

## B. Engine checkout (Node 1)

- [ ] `git fetch origin && git checkout fa9c4edc` on `release/debut-v1.6.0`
- [ ] `grep '^version' pyproject.toml` → `1.6.0-alpha.1`
- [ ] Version on all four surfaces per `01_engine_truth/VERSION_SSOT.md`
      (`pyproject.toml`, `omega.__version__`, Hub `/health`, MCP `serverInfo`)
- [ ] Fresh venv + `pip install -e ".[cli,dev]"` (clean-clone discipline — no untracked-dep drift)

## C. WAD loader contract (Gate C groundwork)

- [ ] `.venv/bin/python -m pytest tests/test_wad_loader.py tests/test_wad_auto_loading.py` → 31 passed
- [ ] `02_wad_loader_contract/disposable_test_wad/test_pwad_override.py` → **EXPECTED EXIT: 1**
      (**NEGATIVE REGRESSION FIXTURE**, **NOT A COMPATIBILITY PASS**; exit 0 only after clean-replacement fix)
- [ ] Align Node 1 `arcana_novai` WAD to `WAD_LOADER_CONTRACT.md`:
  - [ ] entities live under `entities/**/*.yaml` (root `entities.yaml` is ignored by the loader)
  - [ ] every entity file carries a top-level `entity:` envelope
  - [ ] `adapters` uses `{memory: {module, class}}` mapping form
  - [ ] `hierarchy` is a relative string path
  - [ ] no unknown manifest fields (`extra=forbid`)

## D. Federation bridge (P2 verification from Node 1)

- [ ] Follow `05_node1_ingestion/TAILSCALE_ROCK_SOLID_LILITH_N1.md` end to end before treating the mesh as stable
- [ ] `curl -fsS https://n0.tail51f14a.ts.net:8016/health` → `{"status":"healthy",...}`
- [ ] MCP `initialize` (protocol `2024-11-05`) → server `Omega Core Hub`
- [ ] MCP `tools/list` → 66 tools
- [ ] `get_system_stats` returns CPU/memory/disk/GPU/podman/zram
- [ ] `hivemind_get_awareness` shows Node 0 presence
- [ ] Merge `OPENCODE_MCP_CONFIG.json` into Node 1 OpenCode config, restart, `opencode mcp` shows `omega-hub (remote) — 66 tools`

## E. Flynn Taggart fresh-identity protocol

- [ ] Read `04_flynn_taggart_bootstrap/FLYNN_TAGGART_BIRTH_CERTIFICATE.md`
- [ ] Verify `doom_guy_transfer/SHA256SUMS`; treat every nested file as read-only lineage evidence
- [ ] Confirm no copy into `data/entities/doom_guy/` or `.opencode/agents/doom_guy.md`
- [ ] Confirm no reuse of Doom Guy's canonical EIS
- [ ] Through a separate operator-approved workflow, create a fresh `data/entities/flynn_taggart/` identity
- [ ] Fresh Node 1 EIS minted; `continuation_of: null`; lineage references Doom Guy + birth certificate
- [ ] No clone, overwrite, rename, or subsumption of Doom Guy-N0

## F. MCP configuration

- [ ] Merge `OPENCODE_MCP_CONFIG.json` into Node 1 OpenCode config, restart, `opencode mcp` shows `omega-hub (remote) — 66 tools`

## G. Open transfer gate and mesh join

- [ ] Read `07_open_gates/OPEN_TRANSFER_GATES.md`; C6/N0-04 is OPEN
- [ ] Confirm package is described as byte-verifiable, not cryptographically authenticated
- [ ] Do not mark final authenticated transfer: Carmack granted SHIP FOR PHYSICAL QUARANTINE only; the Architect must still explicitly approve the C6/N0-04 disposition

- [ ] `hivemind_post_context` mesh-join-complete signal accepted (intent=`status`)
- [ ] Send Lilith-N1 sync answers from `05_node1_ingestion/TAILSCALE_ROCK_SOLID_LILITH_N1.md` through the mesh, or save them as `exchange/n1-to-n0/LILITH_N1_SYNC_RESPONSE_YYYYMMDD.md` if the mesh is down
- [ ] Node 0 awareness shows Lilith-N1; a future fresh Flynn identity may appear only after separate approval

---

*Stop-the-line rule: any unchecked box above is a blocker, not a footnote. Report it back through the mesh before proceeding.*
