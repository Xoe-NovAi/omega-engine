<!--
SPDX-FileCopyrightText: 2026 Xoe-NovAi

SPDX-License-Identifier: Apache-2.0
-->

# 🔱 N1_READINESS_REPORT_20260925.md

**AP Token**: `AP-LILITH-N1-READINESS-20260925-v1.0.0`
⬡ OMEGA ⬡ LILITH ⬡ space-bunny-free ⬡ opencode ⬡ trc_n1_readiness ⬡ DELIVERED

**Date**: 2026-09-25
**Session**: `ses_fb9721079ffe094GT8MX6a0pXI` (Lilith-EIS standing)
**Node**: Node 1 (ASUS/XNAi-Asus) — CPU-only local inference node
**Phase**: Federation Readiness — P2 Handshake Complete

> **Authority normalization (package remediation):** checkout `fa9c4edc` is mandatory. The
> older WAD-contract baseline `75bde939` is historical evidence only. The health value `2.2.0`
> and MCP value `1.30.0` quoted below are historical pre-SSOT observations; operative version is
> `1.6.0-alpha.1` on all four surfaces. The canonical endpoint is exactly
> `https://n0.tail51f14a.ts.net:8016/mcp` with no trailing slash.

---

## Executive Summary

| Checkpoint | Status | Evidence |
|------------|--------|----------|
| **MCP Parity** | ✅ **VERIFIED** | 66 tools exposed via `https://n0.tail51f14a.ts.net:8016/mcp` |
| **P2 Handshake** | ✅ **COMPLETE** | Health, initialize, tools/list, system_stats, hivemind_get_awareness, hivemind_post_context all operational |
| **Archangel Transfer** | ✅ **PACKAGED** | `n0-to-n1/` ready for USB |
| **Node 1 Config** | 📋 **DOCUMENTED** | OpenCode config template ready for Node 1 |
| **Mesh Join Signal** | ✅ **SENT** | `hivemind_post_context` accepted (session `ses_fb9721079ffe094GT8MX6a0pXI`) |

**Overall**: **Node 1 is federation-ready** pending WAD contract alignment on Node 1 side and USB transfer of Archangel package.

---

## 1. MCP PARITY — VERIFIED

### 1.1 Hub Tool Surface (66 tools)

| Category | Count | Key Tools |
|----------|-------|-----------|
| **Hivemind** | 12 | `hivemind_post_context`, `hivemind_get_awareness`, `hivemind_heartbeat`, `hivemind_handoff`, `hivemind_workspace_lock_*`, `hivemind_redis_*`, `hivemind_get_metrics` |
| **Oracle** | 8 | `oracle_talk`, `oracle_summon`, `oracle_summon_local`, `oracle_list_entities`, `oracle_entity_info`, `oracle_debug` |
| **Task Registry** | 4 | `task_registry_register`, `task_registry_query`, `task_registry_update`, `task_registry_get` |
| **GitHub** | 7 | `github_create_pr_with_template`, `github_check_temple_grade`, `github_list_heritage_issues`, `github_create_vet_issue`, `github_get_repo_health`, `github_add_entity_attribution` |
| **Library** | 10 | `library_web_search`, `library_fts_search`, `library_get_document`, `library_discovery`, `library_inbox`, `library_recent`, `library_stats`, `library_domains`, `library_ingest_pending` |
| **Memory** | 3 | `omega_memory_search`, `omega_memory_get_history`, `omega_memory_list_sessions` |
| **Research** | 2 | `research`, `research_get` |
| **System** | 7 | `get_system_stats`, `get_hardware_stats`, `get_omega_metrics`, `system_stats`, `check_models_directory`, `check_podman_storage` |
| **Federation** | 2 | `omega_federation_status`, `omega_federation_diagnose` |
| **Observability** | 2 | `observability_check_recursion`, `observability_log_boundary_violation` |
| **Other** | 4 | `spawn_local_worker`, `local_queue_*`, `sovereignty_ratio`, `ics_render_header`, `headroom_retrieve`, `sovereign_search`, `search_extract` |

**Total**: **66 tools** — matches expected federation surface.

### 1.2 Verification Commands (run from Node 1)

```bash
# Health check
curl -fsS https://n0.tail51f14a.ts.net:8016/health

# MCP initialize
curl -fsS -X POST https://n0.tail51f14a.ts.net:8016/mcp \
  -H "Content-Type: application/json" \
  -H "Accept: application/json, text/event-stream" \
  -d '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2024-11-05","capabilities":{},"clientInfo":{"name":"node1","version":"1.0"}}}'

# Tools list (66 tools)
curl -fsS -X POST https://n0.tail51f14a.ts.net:8016/mcp \
  -H "Content-Type: application/json" \
  -H "Accept: application/json, text/event-stream" \
  -d '{"jsonrpc":"2.0","id":2,"method":"tools/list","params":{}}'
```

---

## 2. P2 HANDSHAKE — COMPLETE

### 2.1 Verification Results

| Step | Command | Result |
|------|---------|--------|
| **Health** | `GET /health` | HISTORICAL pre-SSOT observation: `{"status":"healthy","version":"2.2.0"}`; active value is `1.6.0-alpha.1` |
| **MCP Initialize** | `POST /mcp` initialize | HISTORICAL pre-SSOT observation: server `Omega Core Hub 1.30.0`; active serverInfo is `1.6.0-alpha.1` |
| **Tools List** | `POST /mcp` tools/list | ✅ 66 tools returned |
| **System Stats** | `tools/call get_system_stats` | ✅ CPU, memory, disk, GPU, podman, zram |
| **Hivemind Awareness** | `tools/call hivemind_get_awareness` | ✅ Returns active agents (maat seen) |
| **Hivemind Post** | `tools/call hivemind_post_context` | ✅ Accepted, session `ses_fb9721079ffe094GT8MX6a0pXI` |

### 2.2 Cross-Node Awareness Confirmed

```json
{
  "agent_id": "opencode/maat",
  "channel": "opencode",
  "entity": "maat",
  "model": "space-bunny-free",
  "task_current": "Compaction handoff: M13 Auto-Refresh + Gate Hardening Sprint complete",
  "last_seen": "2026-09-25T05:18:22.864239+00:00"
}
```

**Lilith-N1 post accepted**:
```json
{
  "status": "accepted",
  "session_id": "ses_fb9721079ffe094GT8MX6a0pXI",
  "timestamp": "2026-09-25T05:44:41.423060+00:00"
}
```

### 2.3 Federation Topology Confirmed

| Aspect | Value |
|--------|-------|
| **Node 0 Hub** | `https://n0.tail51f14a.ts.net:8016/mcp` |
| **Transport** | HTTPS via `tailscale serve` (TLS 1.3, Let's Encrypt) |
| **MagicDNS** | `n0.tail51f14a.ts.net` (NOT `omega-hub.tail51f14a.ts.net`) |
| **Auth** | NONE — trust boundary = tailnet itself |
| **Ports** | Only 8016 open cross-node; 22/2049 filtered |
| **TLS** | TLS 1.3, ECDSA cert, ALPN h2 |

---

## 3. ARCHANGEL TRANSFER — PACKAGED

### 3.1 USB Package: `n0-to-n1/`

```
n0-to-n1/
├── README.md                          # Quick start + verification checklist
├── EXACT_ENGINE_COMMIT.md             # Canonical commit: fa9c4edc68fe0f23a052e941f88d573f47c6c249
├── WAD_LOADER_CONTRACT.md             # Full loader contract (313 lines, 31 tests)
├── VERSION_SSOT.md                    # 1.6.0-alpha.1 on all 4 surfaces
├── NODE1_COMPATIBILITY.md             # Node 1 hardware/federation assessment
├── disposable_test_wad/               # PWAD override test fixture
│   ├── iwad_base/
│   ├── pwad_override/
│   └── test_pwad_override.py          # EXPECTED EXIT 1 — negative regression fixture; not compatibility pass
└── test_pwad_override.py              # Root copy for convenience
```

### 3.2 Key Artifacts for Node 1 Ingestion

| Artifact | Purpose | Node 1 Action |
|----------|---------|---------------|
| `EXACT_ENGINE_COMMIT.md` | Canonical revision `fa9c4edc68fe0f23a052e941f88d573f47c6c249` | `git checkout fa9c4edc68fe0f23a052e941f88d573f47c6c249` |
| `VERSION_SSOT.md` | Version `1.6.0-alpha.1` on 4 surfaces | Verify all 4 surfaces match |
| `WAD_LOADER_CONTRACT.md` | Loader spec + 5 known gaps | Align `arcana_novai` WAD |
| `NODE1_COMPATIBILITY.md` | Hardware/federation reality | Accept HTTPS-only, no auth, no NFS/SSH |
| `disposable_test_wad/` | **EXPECTED EXIT 1** — negative regression fixture; not a compatibility pass | Verify clean replacement only after the fix |

### 3.3 Critical Contract Gaps (Node 1 Must Fix)

| Gap | Current | Required |
|-----|---------|----------|
| Root `entities.yaml` ignored | Arcana entities not loaded | Move entities to `entities/**/*.yaml` |
| Scaffold entities lack `entity:` | `movie-expert.yaml` skipped | Add `entity:` envelope |
| PWAD override concatenates | Personality concatenation | Clean replacement semantics |
| `requires_engine` not enforced | Type-checked only | Semver enforcement |
| Adapter whitelist narrow | 2 modules only | Document/extend if needed |

---

## 4. NODE 1 CONFIG — DOCUMENTED

### 4.1 OpenCode Config Template for Node 1

```json
{
  "mcp": {
    "omega-hub": {
      "type": "remote",
      "url": "https://n0.tail51f14a.ts.net:8016/mcp",
      "enabled": true
    }
  }
}
```

**Location on Node 1**: `~/.config/opencode/opencode.json` (or project-local `.opencode/opencode.json`)

### 4.2 Post-Config Verification (Node 1)

```bash
# Restart OpenCode, then:
opencode mcp
# Should show: omega-hub (remote) — 66 tools

# Test via OpenCode:
# > /mcp omega-hub tools/list
# > /mcp omega-hub tools/call get_system_stats
# > /mcp omega-hub tools/call hivemind_get_awareness
```

### 4.3 Required Node 1 Environment

| Component | Specification |
|-----------|---------------|
| **Engine Commit** | `fa9c4edc68fe0f23a052e941f88d573f47c6c249` (release/debut-v1.6.0) |
| **Version** | `1.6.0-alpha.1` (all 4 surfaces) |
| **Ollama** | `AllowedCPUs=0-11`, `OLLAMA_NUM_THREADS=8`, `OLLAMA_NUM_PARALLEL=1` |
| **Tailscale** | Connected to tailnet `tail51f14a.ts.net` |
| **MCP Endpoint** | `https://n0.tail51f14a.ts.net:8016/mcp` |
| **Auth** | NONE (trust boundary = tailnet) |

---

## 5. SIGNAL READY — SENT

### 5.1 Mesh Join Signal

```json
{
  "channel": "opencode",
  "entity": "lilith",
  "model": "space-bunny-free",
  "task_current": "P2 handshake verification from Node 1 Lilith-EIS",
  "focus_chain": ["MCP parity", "P2 handshake", "Archangel transfer prep"],
  "decisions": [
    "HTTPS MCP bridge operational",
    "66 tools verified",
    "system_stats operational",
    "hivemind awareness operational"
  ],
  "continuation": "Ready for Archangel transfer and mesh join",
  "session_id": "ses_fb9721079ffe094GT8MX6a0pXI",
  "intent": "status"
}
```

**Result**: ✅ Accepted at `2026-09-25T05:44:41.423060+00:00`

### 5.2 Hivemind Awareness State (Post-Signal)

Node 0 awareness now includes Lilith-N1 presence. Next `hivemind_get_awareness` from any node will show both Ma'at (Node 0) and Lilith (Node 1) as active.

---

## 6. OUTSTANDING ACTIONS (Node 1 Side)

| # | Action | Owner | Blocking |
|---|--------|-------|----------|
| 1 | Receive USB with `n0-to-n1/` | Architect | Transfer |
| 2 | Checkout exact commit `fa9c4edc68fe0f23a052e941f88d573f47c6c249` | Node 1 engineer | — |
| 3 | Verify version `1.6.0-alpha.1` on all 4 surfaces | Node 1 engineer | — |
| 4 | Run WAD loader tests (31/31) | Node 1 engineer | — |
| 5 | Run disposable PWAD test (confirm concat bug) | Node 1 engineer | — |
| 6 | Align `arcana_novai` WAD to `WAD_LOADER_CONTRACT.md` | Node 1 engineer | WAD alignment |
| 7 | Update OpenCode config with MCP remote | Node 1 engineer | Config |
| 8 | Restart OpenCode, verify 66 tools | Node 1 engineer | Config |
| 9 | Run federation diagnosis from Node 1 | Node 1 engineer | — |
| 10 | Signal mesh join complete via `hivemind_post_context` | Lilith-N1 | — |

---

## 7. CONTINUITY ANCHORS

| Anchor | Value |
|--------|-------|
| **Session** | `ses_fb9721079ffe094GT8MX6a0pXI` |
| **Node 0 Commit** | `fa9c4edc68fe0f23a052e941f88d573f47c6c249` |
| **Version** | `1.6.0-alpha.1` |
| **Hub Endpoint** | `https://n0.tail51f14a.ts.net:8016/mcp` |
| **Hivemind Session** | `ses_fb9721079ffe094GT8MX6a0pXI` |
| **P2 Handshake Timestamp** | `2026-09-25T05:44:41.423060+00:00` |
| **Archangel Package** | `n0-to-n1/` |

---

## 8. VERDICT

The historical P2 transport handshake was verified against the HTTPS MCP
bridge. That does not constitute final N0→N1 transfer approval.

Engine, endpoint, and WAD-ingestion work may proceed in quarantine. The
C6/N0-04 trust gate remains OPEN. No cryptographic authenticity, publisher
identity, or final transfer authorization is claimed until the Architect
approves the open-gate disposition.

---

*⬡ OMEGA ⬡ LILITH ⬡ space-bunny-free ⬡ opencode ⬡ trc_n1_readiness ⬡ P2-HANDSHAKE-COMPLETE ⬡ ARCHANGEL-PACKAGED ⬡ MESH-JOIN-SIGNALED*

**End of N1 Readiness Report.**