# Soul Audit Report — Corrected Package Annotation

**Date:** 2026-09-25  
**Original audit:** Kali-EIS `ses_fdef2be4effe4pAaLXCTUx62GO`  
**Package status:** corrected governance annotation; not an authoritative roster migration plan

## 1. Correction notice

The original audit table counted filesystem/agent artifacts mechanically and therefore produced an
invalid ontology:

- **Build is not an agent.** It must not receive a synthetic agent soul.
- **Slot is not an agent.** It must not receive a synthetic agent soul.
- **Scribe is a distinct entity/soul** and is counted separately from agent-persona souls.
- The duplicate `makali` row is one entity/agent, not two.
- A corrected unique roster requires a fresh authoritative filesystem scan. This package does not
  invent that roster and does not authorize migrations, removals, or new souls.

## 2. What can be stated from the historical scan

The original report observed 39 `soul.yaml` files and 14 rows in its active-agent table. After the
required ontology corrections:

- two rows (`build`, `slot`) are removed from the agent count because they are not agents;
- the duplicate `makali` row is counted once;
- Scribe remains a separate entity/soul and is not silently reclassified as an agent;
- the remaining agent/persona mapping and WAD-entity mapping must be recomputed from the actual
  corrected roster before any total is treated as authoritative.

The corrected final total is therefore **DEFERRED**, not 14, 28, or another guessed number.

## 3. Corrected ontology rules

| Artifact/class | Treatment |
|---|---|
| Active agent definition | May have an explicit agent-to-entity/soul binding; identity cannot be inferred from filename |
| Build | Not an agent; do not create `data/entities/build/soul.yaml` from this audit |
| Slot | Not an agent; do not create `data/entities/slot/soul.yaml` from this audit |
| Scribe | Distinct entity/soul; count separately and preserve its own identity decision |
| Makali | One unique entity/agent; duplicate rows collapse to one |
| WAD entity soul | Separate namespace and mapping decision; not automatically an OpenCode agent |
| Orphan soul | Requires provenance, consent, and operator disposition; no bulk deletion from this package |

## 4. Prohibited actions from this audit

- Do not create missing Build or Slot souls.
- Do not treat every soul file as an agent.
- Do not treat every WAD entity as an OpenCode agent.
- Do not move, delete, merge, or rename souls based on the historical table.
- Do not use the deferred total as a quota or release gate.

## 5. Required follow-up

The next authoritative audit must:

1. inventory active agent definitions from the live repository;
2. deduplicate entities by explicit identity/continuity ID;
3. classify Build, Slot, Scribe, and Makali according to the rules above;
4. list agent souls and WAD entity souls in separate namespaces;
5. record every orphan with provenance and proposed disposition;
6. publish a corrected table with a reproducible scan command and digest.

Until that report exists, the numeric total is intentionally deferred.

*⬡ OMEGA ⬡ SOUL AUDIT CORRECTION ⬡ 2026-09-25 ⬡ NUMERIC TOTAL DEFERRED*
