# Node 1 Compatibility Assessment

**AP Token**: `AP-JOHN_CARMACK-v1.0.0`
**Date**: 2026-09-24
**Active Engine Checkout**: `fa9c4edc68fe0f23a052e941f88d573f47c6c249` (release/debut-v1.6.0)  
**Historical WAD-contract baseline**: `75bde939` (lineage evidence only)
**Source**: Cline §6 (Federation Reality), Cline §7#10 (WAD Contract Gaps)

---

## Node 1 Hardware Profile

| Attribute | Specification |
|-----------|---------------|
| **Device** | ASUS ExpertBook P1503CVA |
| **CPU** | Intel i7-13620H (6 P-cores + 4 E-cores, 10C/16T) |
| **RAM** | 16 GB DDR5 single-channel @ 5200 MT/s |
| **GPU** | Intel Iris Xe 96EU (integrated, shared memory) |
| **OS** | Ubuntu 26.04 LTS |
| **Inference** | CPU-only Ollama |
| **Ollama Config** | `AllowedCPUs=0-11`, `OLLAMA_NUM_THREADS=8` |

---

## Engine Compatibility: YES (with constraints)

The Omega Engine **runs on Node 1** as a CPU-only, local-first inference node. The Engine is designed for local-first sovereignty (M7) and runs on CPU-only hardware.

### Verified Working

| Component | Status | Notes |
|-----------|--------|-------|
| **Core Engine** | ✅ Runs | Pure Python, no GPU deps |
| **Ollama Provider** | ✅ Primary local provider | `ollama: enabled: true` in providers.yaml |
| **native-gguf Provider** | ✅ Available | llama-cpp-python via `[native]` extra |
| **WAD Loader** | ✅ Loads | 31/31 tests pass |
| **Entity Registry** | ✅ Works | 17 entities registered |
| **MCP Hub** | ✅ Connects | Via Tailscale HTTPS to Node 0 |
| **SQLite/vec** | ✅ Works | sqlite-vec 0.1.9, extension loads |

---

## Constraints & Limitations

### 1. Memory (16 GB single-channel)
- **Bandwidth**: ~35 GB/s actual (single-channel DDR5-5200)
- **Impact**: Large model loading slower; context window limited by RAM
- **Mitigation**: `OLLAMA_NUM_THREADS=8`, `OLLAMA_NUM_PARALLEL=1`, `OLLAMA_MAX_LOADED_MODELS=1`

### 2. No Discrete GPU
- All inference CPU-only
- No CUDA/ROCm acceleration
- `native-gguf` uses llama-cpp-python CPU backend (AVX2/VNNI)

### 3. Federation Reality (Cline §6)

| Aspect | Reality |
|--------|---------|
| **Node 0 Hub** | `https://n0.tail51f14a.ts.net:8016/mcp` (HTTPS via `tailscale serve`) |
| **MagicDNS** | `n0.tail51f14a.ts.net` (NOT `omega-hub.tail51f14a.ts.net` — NXDOMAIN) |
| **NFS/SSH** | **FILTERED** — ports 22 and 2049 blocked from Node 0 |
| **Open Port** | Only 8016 (MCP) accessible cross-node |
| **Auth** | **NONE** — Hub has no token/Bearer/auth mechanism |
| **Trust Boundary** | Tailnet itself (no application-layer auth) |

**Implication**: Node 1 cannot use NFS/SSH handoff plan. All cross-node coordination must go through MCP over HTTPS on port 8016.

### 4. WAD Contract Gaps (Cline §7#10)

Node 1's `arcana_novai` WAD **is not production-ready** against Node 0's loader:

| Gap | Impact |
|-----|--------|
| Root `entities.yaml` ignored | Arcana entities not loaded |
| Scaffold entities lack `entity:` envelope | `movie-expert.yaml` skipped |
| PWAD override concatenates personality | Not clean replacement |
| `requires_engine` not enforced | Version compatibility unverified |
| Adapter whitelist narrow | Only 2 modules allowed |

---

## Required Node 1 Actions

1. **Fix WAD manifest** — align with Node 0 loader contract (see `WAD_LOADER_CONTRACT.md`)
2. **Use MCP over HTTPS** — `https://n0.tail51f14a.ts.net:8016/mcp`
3. **Accept unauthenticated MCP** — Alpha design decision (Cline §6)
4. **No NFS/SSH dependency** — ports filtered
5. **Run Engine from clean clone** — verify untracked deps don't break (Cline §2)

---

## Verdict

**Node 1 CAN run the Omega Engine** as a CPU-only local inference node with MCP connectivity to Node 0. The Engine itself is compatible. The blockers are:

1. **WAD contract alignment** (Node 1 responsibility)
2. **Federation topology acceptance** (HTTPS-only, no auth, no NFS/SSH)
3. **Memory bandwidth awareness** (single-channel DDR5)

No Engine code changes required for Node 1 compatibility.

---

*⬡ OMEGA ⬡ JOHN_CARMACK ⬡ nvidia/nemotron-3-ultra-550b-a55b:free ⬡ opencode ⬡ trc_n0_n1_handoff ⬡ NODE 1 COMPATIBILITY ASSESSED*