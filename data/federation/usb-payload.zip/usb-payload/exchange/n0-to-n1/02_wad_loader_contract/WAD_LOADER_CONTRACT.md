# WAD Loader Contract Specification

**AP Token**: `AP-JOHN_CARMACK-v1.0.0`
**Date**: 2026-09-24
**Active Engine Checkout**: `fa9c4edc68fe0f23a052e941f88d573f47c6c249` (release/debut-v1.6.0)  
**Historical contract baseline**: `75bde939` (lineage evidence only)
**Source**: `src/omega/oracle/wad_loader.py` (primary), `tests/test_wad_loader.py` (contract tests)

---

## 1. Manifest Schema

### 1.1 Required Fields (V1 Core)

```python
MANIFEST_FIELD_TYPES = {
    "name": str,
    "version": str,
    "entities": (list, dict),
    "adapters": dict,  # mapping-only: memory -> {module, class}
}
```

### 1.2 Optional V2 Heritage Fields (Explicit Allow-List)

```python
MANIFEST_V2_OPTIONAL_FIELD_TYPES = {
    "author": str,
    "description": str,
    "license": str,
    "type": str,              # "iwad" | "pwad"
    "mode": str,
    "requires_engine": str,   # semver string, e.g., ">=1.6.0"
    "startup": dict,          # {"message": "..."}
    "voices": (list, dict),
    "vr_scenes": (list, dict),
    "dependencies": (list, dict),
    "hierarchy": str,         # RELATIVE PATH to hierarchy.yaml
}
```

### 1.3 Unknown Field Behavior

**REJECT** — `extra=forbid` semantics. The loader merges V1 + V2 allow-lists and rejects any field not in the union:

```python
known_manifest_fields = set(field_types.keys())
unknown_manifest_fields = set(manifest.keys()) - known_manifest_fields
if unknown_manifest_fields:
    raise ValueError(
        f"WAD {stack_name} manifest has unknown fields: {sorted(unknown_manifest_fields)}. "
        f"Known fields: {sorted(known_manifest_fields)}"
    )
```

---

## 2. `adapters` Schema

> **Current-loader limit:** persona-specific manifest fields such as `entity`, `soul`, `prompt`,
> `capabilities`, `domains`, `model_preferences`, `runtime`, and inline `provenance` are **not
> accepted by the current WAD loader**. The Persona WAD architecture in this package is a
> future design proposal. It requires a separate reviewed adapter/schema before any such fields
> can be used. This document does not change Engine Core or the loader.

### 2.1 Structure

The manifest `adapters` field is **mapping-only**. List form is invalid. The only supported shape is:

```yaml
adapters:
  memory:
    module: "omega.memory.adapters.mnemosyne_adapter"
    class: "MnemosyneAdapter"
```

### 2.2 Adapter Whitelist (Hardcoded)

```python
ADAPTER_MODULE_WHITELIST: Set[str] = {
    "omega.memory.adapters",
    "omega.memory.adapters.mnemosyne_adapter",
}
```

**Behavior**: If `module_path not in ADAPTER_MODULE_WHITELIST`, the adapter is rejected (logged error, WAD load continues without adapter). No arbitrary path allowance. No path containment check beyond exact-string whitelist membership.

### 2.3 Registration Flow

1. Dynamic import of `module_path`
2. Get `class_name` attribute
3. Instantiate `adapter_class()`
4. Call `await instance.initialize()`
5. Verify `isinstance(instance, IMemoryAdapter)`
6. Register with `MemoryAdapterRegistry`
7. Map all entities from this WAD to the adapter

---

## 3. `hierarchy` Schema

### 3.1 Type

**String** — relative path under the WAD root.

### 3.2 Resolution Logic

```python
if "hierarchy" in manifest:
    h_path = wad_path / manifest["hierarchy"]
    if await anyio.Path(h_path).exists():
        hierarchy_path = h_path
else:
    default_h_path = wad_path / "hierarchy.yaml"
    if await anyio.Path(default_h_path).exists():
        hierarchy_path = default_h_path
```

**No content/schema validation** is performed on the hierarchy file by the loader.

---

## 4. Entity Envelope

### 4.1 File Discovery

Loader scans `<wad>/entities/**/*.yaml` only. Root-level `entities.yaml` is **not scanned**.

### 4.2 Naming

- `soul.yaml` → entity name from parent directory
- Other `.yaml` → entity name from filename stem

### 4.3 Required Top-Level Key

Every entity file **MUST** have a top-level `entity:` key:

```yaml
entity:
  name: "my_entity"
  domains: ["domain1"]
  model: "qwen3-1.7b-q6_k"
  personality: "I am an entity"
  temperature: 0.7
  context_window: 8192
  slots: []
```

### 4.4 Known Entity Fields

```python
ENTITY_FIELD_TYPES = {
    "name": str,
    "domains": list,
    "model": str,
    "personality": str,
    "temperature": (int, float),
    "context_window": int,
    "slots": list,
}
```

Plus loader-injected: `wad_source`, `priority`

### 4.5 Unknown Entity Field Behavior

**REJECT** — entity file skipped with warning:

```python
known_fields = set(ENTITY_FIELD_TYPES.keys()) | {"wad_source", "priority"}
unknown_fields = set(ent_data.keys()) - known_fields
if unknown_fields:
    logger.warning(f"Entity {entity_name} has unknown fields: {sorted(unknown_fields)}. Skipping.")
    continue
```

### 4.6 Range Constraints

| Field | Range |
|-------|-------|
| `temperature` | `[0.0, 2.0]` |
| `context_window` | `[1, 131072]` |
| `port` (optional) | `[1, 65535]` |

### 4.7 Other Constraints

- Entity name length ≤ 128 chars
- Domains count ≤ 20
- File size ≤ 1 MB

---

## 5. Dependency Ordering & Priority

### 5.1 Discovery

Each WAD directory with `manifest.yaml` is discovered. Metadata extracted:
- `type`: "iwad" (default) or "pwad"
- `dependencies`: list of WAD names
- `priority`: integer (default 0)

### 5.2 Load Order Resolution

1. **IWADs load before PWADs** — base priority: IWAD=100, PWAD=0
2. **Dependencies before dependents** — topological sort (Kahn's algorithm)
3. **Circular dependencies** → `OmegaError` raised

```python
def effective_priority(wad: Dict[str, Any]) -> int:
    base = 100 if wad["type"] == "iwad" else 0
    return base + wad.get("priority", 0)
```

### 5.3 Unknown Dependencies

Logged as warning, ignored (not a load failure).

---

## 6. Engine-Version Enforcement

### 6.1 Current State

`requires_engine` is **type-checked only** (must be `str`). **No semantic version comparison or enforcement exists.**

```python
# In MANIFEST_V2_OPTIONAL_FIELD_TYPES:
"requires_engine": str,
```

### 6.2 Required Fix

Implement semver parsing and enforcement:

```python
# Pseudo-code for required enforcement
from packaging.version import Version
from packaging.specifiers import SpecifierSet

engine_version = Version("1.6.0-alpha.1")  # from pyproject.toml
required = SpecifierSet(manifest.get("requires_engine", ">=0.0.0"))
if engine_version not in required:
    raise ValueError(f"Engine {engine_version} does not satisfy requires_engine: {required}")
```

---

## 7. PWAD Override Semantics

> **NEGATIVE REGRESSION FIXTURE — NOT A COMPATIBILITY PASS.**  
> At sealed checkout `fa9c4edc`, `test_pwad_override.py` has **EXPECTED EXIT: 1**. Exit 0 is valid only after a sealed engine release containing the clean-replacement fix.

### 7.1 Current Behavior at `fa9c4edc` (BUG)

**Personality concatenation, not replacement.**

When a PWAD loads an entity that already exists in the registry (from IWAD or base `entities.yaml`), the sealed `EntityRegistry` shadow-stack projection **concatenates** personality:

```python
# In EntityRegistry._project_entity() at fa9c4edc
if layer.personality and layer.personality != projected.personality:
    projected.personality = (
        f"{layer.personality}\n\n{projected.personality}"
        if projected.personality
        else layer.personality
    )
```

**Observed**: PWAD entity with `personality: "probe"` + base entity with `personality: "base"` → `"probe\n\nbase"`

### 7.2 Required Semantics: CLEAN REPLACEMENT

PWAD override should **replace** the base entity personality, not concatenate. The loader's priority gate already controls whether a layer is added:

```python
# In WADLoader._load_entities()
if priority <= existing_priority:
    logger.info(f"Entity {entity_name} already registered (priority {existing_priority} >= {priority}). Skipping.")
    continue
# Higher priority → layer added → but sealed projection CONCATENATES
```

**Required fix**: Change projection so that a non-empty personality from a higher-priority layer completely replaces the projected personality. A Node 0 clean-replacement implementation is staged for PR/release; it is not part of sealed checkout `fa9c4edc`.

**Verification for this package**: The regression fixture must exit 1 with “BUG CONFIRMED: Personality CONCATENATION detected!” The wrapper `run_pwad_regression.sh` translates fixture exit 1 → shell exit 0 (PASS).

---

## 8. Contract Tests (Source of Truth)

Run: `pytest tests/test_wad_loader.py tests/test_wad_auto_loading.py -v`

**31 tests passing** covering:
- Valid WAD load
- Path traversal rejection
- Nonexistent WAD
- Malformed manifest
- Missing required fields
- Duplicate entity handling (priority-based)
- Flat entity YAML vs `soul.yaml` directory structure
- Mixed entity types
- Invalid YAML handling
- Empty entity files
- Wrong field types (e.g., temperature as string)
- Oversized manifest (>1MB) rejection
- Empty name/version rejection
- Oversized entity file rejection
- Missing `entity:` key rejection
- Adapter whitelist enforcement

---

## 9. Known Gaps (from Cline §7#10)

1. **Root `entities.yaml` ignored** — not scanned by loader
2. **Some scaffold entities lack `entity:` envelope** — e.g., `arcana_novai/entities/personal/movie-expert.yaml`
3. **PWAD override concatenates personality** instead of replacing; clean replacement is staged for PR/release and is not in sealed `fa9c4edc`
4. **`requires_engine` has no semver enforcement** — type-checked only, no semantic version comparison
5. **Adapter whitelist is narrow** — only 2 modules allowed (`omega.memory.adapters`, `omega.memory.adapters.mnemosyne_adapter`)

---

*⬡ OMEGA ⬡ JOHN_CARMACK ⬡ nvidia/nemotron-3-ultra-550b-a55b:free ⬡ opencode ⬡ trc_n0_n1_handoff ⬡ WAD LOADER CONTRACT DELIVERED*