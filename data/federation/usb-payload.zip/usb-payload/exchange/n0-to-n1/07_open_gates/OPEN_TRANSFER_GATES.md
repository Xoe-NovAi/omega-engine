# Open Transfer Gates

## C6 / N0-04 — OPEN

No ratified C6 contract, publisher key identity, publisher trust root, detached signature, or
negative tamper-verification bundle is present in this package. The root and nested SHA ledgers
prove byte integrity only. This package is **byte-verifiable, not cryptographically authenticated**.

### Architect decision gate — explicit

**Decision owner:** Architect  
**Physical USB quarantine transport:** **APPROVED** as a personally controlled operation  
**C6/N0-04 gate state:** **OPEN**  
**Final authenticated transfer:** **BLOCKED / NOT CLAIMED**

The Architect has approved physical USB transfer only for movement into Node 1 quarantine. This
approval is not cryptographic authenticity, publisher identity, C6 ratification, or final transfer
authorization. Quarantine transport must remain explicitly labeled and must not be represented as
final authenticated transfer. The Architect must explicitly accept or reject the C6/N0-04
open-gate disposition before any final approved transfer. This package does not invent a signature,
trust root, publisher identity, or approval.

Required before final transfer approval:

1. ratify C6 and identify the publisher key;
2. provide a pinned trust root and detached signature over the exact root manifest digest;
3. define rotation/revocation policy;
4. provide a verification command and expected output;
5. demonstrate that a modified payload is rejected;
6. record the Architect's explicit accept/reject decision.

Until that decision is recorded, C6/N0-04 remains OPEN and the package cannot claim cryptographic
authenticity or final transfer authorization.

## External Phase 4 report

`data/coordination/GROKSTER_PHASE4_CONSOLIDATION_REPORT_20260925.md` was reviewed externally by
Grokster during package assembly but is **not included in this USB package**. It is not an
authority, trust artifact, or substitute for this package's manifest and checksums. The package's
own `README_FIRST.md`, `MANIFEST.yaml`, and ledgers are authoritative for the files actually present.

## Independent final audit — physical quarantine

Carmack's final audit returned **SHIP FOR PHYSICAL QUARANTINE**. Controlled USB movement into
Node 1 quarantine may proceed, labeled explicitly as quarantine transport. This audit is separate
from final authenticated-transfer authorization: C6/N0-04 remains OPEN, and no cryptographic
authenticity, publisher identity, or final transfer authorization is claimed until the Architect
explicitly accepts the open-gate disposition.

## Architect ratification — unauthenticated HTTPS MCP for Alpha (Antigravity §9.2)

**RATIFIED BY THE ARCHITECT FOR THE ALPHA STAGE.** Transport posture for Alpha: HTTPS MCP over
Tailscale Serve with tailnet-level trust and no application-layer bearer token is approved
("proceed with unauthenticated HTTPS MCP for Alpha PR if that speeds up time to PR"). This
closes Antigravity review question §9.2.

**Scope limits — this ratification does NOT:**
- close C6/N0-04 (it stays **OPEN**);
- create a publisher trust root;
- provide a detached signature;
- authorize final authenticated transfer.

The package stays **byte-verifiable, not cryptographically authenticated**, and no final
authenticated transfer is claimed.
