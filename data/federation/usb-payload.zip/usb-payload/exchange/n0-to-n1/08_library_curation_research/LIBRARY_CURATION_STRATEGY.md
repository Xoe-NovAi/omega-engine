<!--
SPDX-FileCopyrightText: 2026 Xoe-NovAi
SPDX-License-Identifier: Apache-2.0
-->

# Library Curation Strategy

**Status**: Research recommendation for Node 1; not a substitute for a rights review.
**Primary consumers**: Node 1's five WanderGround domains, the Well, MemPalace projection, and future per-entity seed libraries.

## 1. Curation Principle

> **A corpus is not a pile of downloads. It is a set of claims with provenance, rights, identity, quality, and lifecycle state.**

The collector's job is discovery. The curator's job is selection. The operator's job is promotion. The entity's job is consumption with citation. No stage may silently perform the next stage's authority.

## 2. Source Classes

Every item receives exactly one primary class and may have secondary access labels.

| Class | Definition | Examples | Default promotion |
|---|---|---|---|
| `S0_PRIMARY_TEXT` | Original or authoritative full text with clear public/open rights. | Public-domain edition, CC0 book, explicitly CC BY article | Eligible after rights + hash + citation gate. |
| `S1_OPEN_LICENSE` | Full text under a named open license with obligations. | CC BY, CC BY-SA, Open Government Licence | Eligible only with license, attribution, share-alike, and jurisdiction fields. |
| `S2_CATALOG_METADATA` | Bibliographic/catalog record without full-text permission. | Open Library, IA metadata, HathiTrust rights metadata, DOAB metadata | Shareable as metadata; never imply full-text rights. |
| `S3_ABSTRACT_OR_INDEX` | Abstract, citation, graph, or index record. | Crossref abstract, PubMed abstract, Semantic Scholar record | Shareable only under provider terms; full text remains separate. |
| `S4_RESTRICTED_METADATA` | Metadata is available but content access is restricted or requires account/contract. | HathiTrust in-copyright records, publisher pages | Metadata seed only with explicit restriction label; no full text. |
| `S5_LOCAL_PRIVATE` | Operator-owned notes, personal material, private correspondence, licensed internal material. | The Well private records, personal archives, licensed research | Local/private only; never in public/shareable seed or USB by default. |
| `S6_DERIVED` | Summaries, translations, embeddings, extracted claims, or model outputs. | Curated cards, DPO pairs, MemPalace drawers | Must link parent item(s), model, prompt/schema, and rights status; never outrank parent evidence. |
| `S7_UNKNOWN_OR_DISPUTED` | Rights, identity, factual claim, or provenance cannot be established. | Broken link, ambiguous mirror, contradictory metadata | Quarantine; no public promotion. |

## 3. Trust Ranking

Trust is **source-and-claim specific**, not a single universal score. A high-trust catalog can carry a low-trust abstract; a low-trust mirror can be useful for discovery but not evidence.

### 3.1 Evidence priority

1. Primary publisher/author/repository record with stable identifier and rights statement;
2. official library/catalog metadata with rights/access fields;
3. Crossref/OpenAlex/PubMed/Europe PMC metadata and citation links;
4. recognized open repository or public-domain edition;
5. reputable secondary analysis with citations;
6. community annotation or mirror, used for discovery only until corroborated;
7. search snippet, generated summary, unattributed web page, or model output.

### 3.2 Claim-level trust

For each extracted claim, retain:

```yaml
claim_id: stable-id
claim_text: "..."
parent_item_ids: []
source_class: S3_ABSTRACT_OR_INDEX
independence_group: doi:10....
confidence: 0.0-1.0
supporting_item_ids: []
contradicting_item_ids: []
status: supported | disputed | stale | unverified
```

Two pages reproducing the same press release are one evidence family, not two independent confirmations.

## 4. Freshness and Rotation

Freshness is a property of the claim, not automatically of the document.

- **Fast-rotating**: APIs, model cards, terms, release notes, legal pages. Recheck before every release-scale run and store `terms_checked_at`.
- **Research metadata**: Crossref/OpenAlex/Semantic Scholar/arXiv/PubMed. Re-query by update window and retain version/date metadata.
- **Books/classics**: stable content, but rights and edition metadata still need revalidation.
- **Local operational docs**: Node 0/Node 1 specs and Well records. Tie validity to a source revision or content hash.
- **Expired/retracted**: mark `status: superseded`, `retracted`, or `rights_changed`; do not delete the provenance record.

A corpus should support `freshness_class` and `valid_until` without rewriting the original item.

## 5. Relevance and Domain Profiles

Node 1's received architecture describes five broad domains: local AI, consciousness/time/reality, classical studies, psychology/philosophy, and video games as worlds/simulations. These are useful initial profiles, not a final ontology. [L1]

Each entity/domain profile should declare:

```yaml
domain_id: local_ai
purpose: "..."
must_have_topics: [...]
secondary_topics: [...]
excluded_topics: [...]
source_class_weights:
  S0_PRIMARY_TEXT: 0.9
  S1_OPEN_LICENSE: 0.8
  S2_CATALOG_METADATA: 0.65
  S3_ABSTRACT_OR_INDEX: 0.6
  S4_RESTRICTED_METADATA: 0.35
  S5_LOCAL_PRIVATE: 0.0   # unless explicitly authorized for this domain
preferred_languages: [en]
date_range: ...
citation_style: ...
```

A relevance score is not a quality score. A recent low-quality source can be relevant; a canonical source can be irrelevant to an entity.

## 6. Deduplication and Identity

Use layered identity:

1. **Exact content**: SHA-256 of stored bytes;
2. **Canonical accession**: DOI, PMID, PMCID, arXiv ID, ISBN, OLID, HathiTrust ID, handle, or local stable ID;
3. **Canonical URL**: landing page, not CDN/file URL;
4. **Title/author/year fingerprint**: collision candidate only;
5. **Near-duplicate text**: shingled/minhash/SimHash or embedding similarity, followed by human review;
6. **Edition relationship**: different editions are related, not duplicates;
7. **Version relationship**: arXiv versions and repository revisions retain lineage.

Never deduplicate solely by title. Never merge an open edition with a restricted edition merely because the text is similar.

The local `CuratedDocument` currently generates a UUID-like `doc_id`; the local CAS uses content hashes. [L0] Node 1 should add a stable source-derived identity and a separate random instance ID if needed.

## 7. Contradiction Handling

1. Detect disagreement between metadata, abstract, full text, and independent sources.
2. Preserve both claims and their provenance; never overwrite the losing claim silently.
3. Classify the disagreement:
   - metadata error;
   - version/date drift;
   - definition mismatch;
   - empirical contradiction;
   - rights/access contradiction;
   - extraction error;
   - unresolved.
4. Prefer primary/current sources for factual metadata, but do not use authority to suppress a legitimate scientific dispute.
5. Mark a claim `DISPUTED` when credible sources disagree.
6. Route consequential contradictions to a human or domain curator.
7. Store a `resolution_note` with the decision and evidence.

The local `TriangulationVerifier` has a useful T1/T3 disagreement concept but its independence check is still a placeholder. [L0] This is a candidate for measured improvement, not a claim of solved truth.

## 8. Quality and Evidence Scoring

A practical score should be explainable:

```text
quality = 0.25 provenance
        + 0.20 identity
        + 0.15 rights
        + 0.15 source authority
        + 0.10 completeness
        + 0.10 freshness-fit
        + 0.05 structure
```

Hard gates override the score:

- no rights decision → not promotable;
- no citation/accession → not promotable;
- secret/PII scan failure → quarantine;
- source conflict unresolved → `DISPUTED`, not silently accepted;
- full text without permission → never promote.

The local CurationPipeline's five-factor heuristic (freshness, completeness, authority, structure, accessibility) is useful as a first-pass signal only. It must not be presented as peer review, legal clearance, or factual truth. [L0]

## 9. Promotion Gates

### Gate P0 — Collection Safety

- source policy and access pattern captured;
- contact/User-Agent configured;
- rate limit and retry budget set;
- no secrets/personal material in request path;
- collector version and config hash captured.

### Gate P1 — Identity and Provenance

- canonical URL/accession captured;
- content SHA-256 stored;
- source and retrieval timestamps captured;
- parent/alternate relationships recorded;
- citation generated and validated.

### Gate P2 — Rights and Privacy

- source class assigned;
- license/rights URL captured or explicitly marked unknown;
- jurisdiction recorded;
- attribution/share-alike obligations recorded;
- public/private destination selected;
- human/policy approval recorded.

### Gate P3 — Curation Quality

- relevance profile matched;
- quality factors computed;
- duplicate candidates resolved;
- contradictions recorded;
- claims have parent evidence.

### Gate P4 — Consumption

- entity/domain authorization exists;
- read-only seed library generated;
- FTS/vector dimensions and model pinned;
- local/private boundary tested;
- rollback/export path verified.

## 10. Evaluation Without Self-Congratulation

Maintain a golden corpus and a query set. Measure:

- metadata completeness;
- rights classification accuracy;
- exact and near-duplicate precision/recall;
- citation integrity;
- extraction success and clean-text rate;
- contradiction detection precision/recall;
- retrieval Recall@k, MRR/nDCG;
- abstention quality when evidence is insufficient;
- stale-source detection;
- private-data leakage (must be zero);
- operator override rate;
- time/cost per promoted item.

A model-generated summary is not evidence. It is a derived artifact whose quality is measured against the parent corpus and citations.

## 11. Read-only Seed Library Contract

A seed library is immutable from the entity's perspective:

```text
seed/
  manifest.yaml
  items/
    <stable-id>/
      metadata.yaml
      citations.yaml
      rights.yaml
      content.<ext>       # only if permitted
      content.sha256
  queries/
  evaluations/
  README.md
```

Entities read and cite seeds. Curators create new versions or proposals. Promotion never mutates the previous seed in place. This prevents a local KB from silently contaminating Engine core or changing the historical record under an entity.

## 12. The Core Curation Rule

> **Collect broadly. Curate narrowly. Preserve completely. Promote only with consent.**

*⬡ OMEGA ⬡ ROC_RACOON ⬡ CURATION-STRATEGY ⬡ 2026-09-25*