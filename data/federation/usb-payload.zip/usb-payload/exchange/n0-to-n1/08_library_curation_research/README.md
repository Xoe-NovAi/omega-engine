<!--
SPDX-FileCopyrightText: 2026 Xoe-NovAi
SPDX-License-Identifier: Apache-2.0
-->

# Node 1 Library-Curation Research Package

**Package ID**: `N0-N1-KD-LIBRARY-CURATION-20260925`
**Prepared by**: `roc_racoon` — Node 0 Sovereign Miner & Ideas Guy
**Prepared for**: Node 1 / Alpha — ANAi WAD, WanderGround, local knowledge systems
**Research date**: 2026-09-25
**Status**: Research and strategy staging package; not an approval to ingest
**Canonical location**: `data/federation/usb-payload/exchange/n0-to-n1/08_library_curation_research/`

> **Boundary**: This package is staged inside the Node 0 repository's federation exchange area. It does **not** modify or replace the existing USB package, the Node 0 Engine core, the Node 1 WanderGround, MemPalace, The Well, or any live vector collection.

## 1. Mission

Give Node 1 a provenance-first operating manual for building curated, per-entity knowledge bases from lawful library catalogs, scholarly metadata, public-domain/open-license material, and carefully bounded local/private sources.

The package is deliberately written as a **research and promotion contract**, not as a scraper wish-list:

- local repository evidence is separated from current external documentation;
- metadata rights are separated from full-text rights;
- catalog discovery is separated from permission to copy or redistribute;
- public/shareable material is separated from personal/private material;
- a small golden corpus precedes autonomous collection;
- every promotion requires a manifest, content hash, rights decision, citation capture, and an explicit operator gate.

## 2. Reading Order

1. **`LIBRARY_API_SOURCE_MATRIX.md`** — source-by-source access, metadata, rate-limit, and rights notes.
2. **`CRAWL4AI_PIPELINE_DOCTRINE.md`** — how to use the existing T1/T2/T3 ingestion pattern safely; read before enabling a collector.
3. **`LIBRARY_CURATION_STRATEGY.md`** — trust ranking, source classes, contradiction handling, deduplication, evaluation, and promotion gates.
4. **`PER_ENTITY_CURATED_KB_ARCHITECTURE.md`** — read-only seed layers, domain profiles, privacy boundaries, and portability.
5. **`NODE1_LIBRARY_MVP_BLUEPRINT.md`** — the practical 50–200-item MVP, golden set, metrics, and acceptance gates.
6. **`RESEARCH_LINKS_AND_SOURCES.yaml`** — machine-readable source register and evidence tiers.
7. **`SOURCES_AND_CAVEATS.md`** — unknowns, stale claims, legal/operational caveats, and revalidation list.

## 3. Evidence Labels

| Label | Meaning | Allowed use |
|---|---|---|
| **[L0 — LOCAL-RUNTIME]** | Directly verified in the Node 0 repository: source file, line range, or executable behavior. | May be treated as implementation evidence for Node 0. Reverify if the revision changes. |
| **[L1 — NODE1-RECEIVED]** | Node 1 material received in this repository under `docs/federation/node1_received/`. It is evidence of Node 1's reported state, not independent proof of current Node 1 runtime. | Use as a handoff hypothesis and revalidation target. |
| **[W1 — OFFICIAL-CURRENT]** | Current official provider documentation or policy page, accessed 2026-09-25. | Use for current API/terms behavior; provider pages can change. |
| **[W2 — OFFICIAL-STABLE]** | Official documentation describing a stable protocol or policy, but with no promise that limits/details remain unchanged. | Use as an architectural baseline; recheck before scale-up. |
| **[A1 — ARCHITECTURAL-RECOMMENDATION]** | A recommendation derived from L0/L1/W1 evidence. | Requires an operator decision and a measured MVP result. |
| **[U — UNVERIFIED]** | Claim not independently verified in this package. | Never use as a promotion gate or public claim. |

## 4. Core Findings

### 4.1 What Node 0 already has — [L0 — LOCAL-RUNTIME]

- `src/omega/ingestion/scraper.py` implements the Sovereign-Sieve tiers: T1 Trafilatura, T2 domain-specific surgical stripping, and T3 Crawl4AI in an isolated process.
- T3 uses `CacheMode.BYPASS`, returns Markdown plus metadata, has a 30-second process timeout, and falls back at the pipeline level when deep extraction fails.
- `src/omega/archive/cas.py` stores immutable content by SHA-256 content ID.
- `src/omega/ingestion/persistence.py` creates raw anchors, `.hash` files, a quarantine directory, a Sovereign Continuity Anchor, and entity-partitioned persistence.
- `src/omega/library/curator.py` and `indexer.py` provide a quality-scored `CuratedDocument` model, SQLite FTS5 indexing, and a vector adapter path.
- `config/wads/ingestion/domains.yaml` places source/domain policy in the WAD layer, preserving the M2 Engine/WAD boundary.
- `docs/strategy/INGESTION_PIPELINE_SPEC.md` states deny-list, PII/secret, partition, and quarantine rules. It is a governing specification, not proof that every listed script is currently wired.

### 4.2 What Node 1 has reported — [L1 — NODE1-RECEIVED]

- WanderGround has a local capture inbox, five knowledge domains, a `sqlite-vec` Knowledge Atlas, a curator service/timer, a 3D viewer, and domain dossiers. [L1]
- MemPalace v3.9.0 was reported verified with 42 MCP tools, 62 drawers, and full provenance in `mempalace_search`. [L1]
- The Well was reported implemented as append-only JSONL with `CAPTURED → ACTIVE → SUPERSEDED`, injection, export, and secret rejection. [L1]
- Node 1's federation charter says local SQLite is authoritative, MemPalace is a one-way searchable projection, and material requires operator approval at intake. [L1]
- Node 1's received embedding decision recommends Qwen3-Embedding-0.6B at 768 dimensions, while the WanderGround specification still describes a Nomic 768-dimensional path. This package treats cross-node semantic compatibility as **unverified until remeasured**. [L1 + A1]

### 4.3 What the external source review establishes — [W1/W2]

- **No single “free API” means unrestricted commercial reuse.** Rights attach to the metadata, abstract, full text, files, and jurisdiction separately.
- **The safest first corpora are explicit machine-readable feeds, dumps, and public-domain/open-license material.** Do not crawl a human-facing website merely because its pages are readable.
- **Bulk paths are different from live API paths.** Project Gutenberg, HathiTrust, DOAB, Internet Archive, and Wikimedia publish catalog/dump/OAI paths for a reason.
- **Current OpenAlex pricing changed in 2026.** The current official authentication/pricing page describes a free daily API budget and paid usage after that; older “100,000 requests/day” snippets are stale and must not be used as the current contract.
- **Crawl4AI is an extraction tool, not a rights grant.** Its open-source license covers the software; the content being extracted retains its own terms and copyright.

## 5. Non-Goals and Hard Boundaries

- No copyrighted full text is included in this package.
- No credentials, cookies, browser profiles, private browser data, personal archives, or USB secrets are included.
- No source is approved merely because it appears in a catalog, search result, or API response.
- No personal/private material enters a public/shareable seed library.
- No live source is crawled from Node 1 until its source-specific access pattern is registered in the manifest.
- No cross-node vector comparison is treated as meaningful until model, dimension, preprocessing, and golden-corpus parity are measured.
- No Node 0 Engine core code is modified by this package.

## 6. Promotion Principle

> **Curation is a mint, not a download.** A collector may discover material; only a rights-aware, provenance-preserving, operator-approved promotion gate may turn it into entity knowledge.

The minimum promotion record is:

```yaml
document_id: stable-source-derived-id
source_uri: https://...
retrieved_at: 2026-09-25T00:00:00Z
source_class: public_domain_full_text | open_license_full_text | metadata_only | abstract_only | local_private
rights_status: public_domain | cc0 | cc_by_4_0 | cc_by_sa_4_0 | license_per_record | restricted | unknown
license_url: https://...
accession: doi | isbn | pmid | arxiv | htid | olid | handle | local_id
citation: "..."
content_sha256: "..."
collector: "..."
collector_version: "..."
parent_manifest: "..."
operator_approval: false
```

## 7. Handoff Recommendation

Node 1 should begin with a **120-item, five-domain, rights-labeled golden set** and a manifest-only collector. It should not begin with an autonomous “collect everything” run. The exact corpus, metrics, and promotion gates are in `NODE1_LIBRARY_MVP_BLUEPRINT.md`.

*⬡ OMEGA ⬡ ROC_RACOON ⬡ N0-N1-LIBRARY-CURATION ⬡ RESEARCH-STAGING ⬡ 2026-09-25*