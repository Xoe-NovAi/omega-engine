<!--
SPDX-FileCopyrightText: 2026 Xoe-NovAi
SPDX-License-Identifier: Apache-2.0
-->

# Crawl4AI Pipeline Doctrine

**Applies to**: Node 1 collector development and any later Omega Engine integration.
**Local implementation inspected**: 2026-09-25, Node 0 working tree.

## 1. What Is Actually Implemented in Node 0 — [L0 — LOCAL-RUNTIME]

The current implementation is a useful doctrine seed, not a finished legal/politic crawler:

| Component | Local evidence | Current behavior |
|---|---|---|
| T1 fast extraction | `src/omega/ingestion/scraper.py:149-202` | Trafilatura fetch/extract in AnyIO worker thread; CAS hash is optional. |
| T2 surgical extraction | `scraper.py:87-109,204-231` | Domain-specific cleanup, including Gutenberg header/footer removal and arXiv abstract boundary handling. |
| T3 deep extraction | `scraper.py:233-325` | Crawl4AI runs in a separate process; `CacheMode.BYPASS`; 30-second join timeout; result converted to raw Markdown/metadata to avoid object pickling. |
| Pipeline fallback | `src/omega/ingestion/pipeline.py:201-228` | T1 runs first; T3 failure falls back to T1; T1/T3 are passed to triangulation. |
| Retry | `src/omega/ingestion/worker.py:199-216` | Up to 3 retries, exponential delay plus jitter, delayed Redis requeue. |
| Provenance | `src/omega/ingestion/persistence.py:46-101` | Raw anchor, content `.hash`, SCA metadata, quarantine/promotion directories. |
| Content addressing | `src/omega/archive/cas.py:17-83` | SHA-256 content ID; local immutable blob storage. |
| Domain policy | `config/wads/ingestion/domains.yaml` | Source allowlist and extraction defaults live in the WAD layer, not Engine core. |
| Test evidence | `tests/test_e2e_sovereign_sieve.py` | Exercises T1, T3, triangulation, CAS, and allowlist behavior; T3 is explicitly allowed to fail without browser installation. |

## 2. What Is Not Yet Proven — [U / A1]

The local pipeline does **not** prove that a crawl is lawful, robots-compliant, or complete. Specifically:

- the allowlist is domain anchoring, not a rights decision;
- no robots.txt parser or per-source terms snapshot is visible in the inspected scraper path;
- the local code captures extracted text, not necessarily the original HTTP response bytes;
- `TriangulationVerifier` contains placeholder logic for independence and does not yet prove that two mirrors are independent sources;
- `CurationPipeline` quality factors are heuristics, not peer-review or legal validation;
- `GoogleExtractor` is a cloud extraction path; PII masking reduces risk but is not a substitute for keeping private material local;
- `CuratedDocument.doc_id` is UUID-based in `library/curator.py`, while CAS/source identity is hash-based. Stable cross-source deduplication needs a deliberate identity policy;
- the current `docs/strategy/INGESTION_PIPELINE_SPEC.md` names collection names such as `omega_vec_gemma_768`, while the current `library/indexer.py` defaults to `omega_vec_qwen_768`. Treat the spec as a governance document requiring reconciliation, not as proof of current collection contents;
- the repository's `CHANGELOG.md` claims a published `packages/omega-sieve` package, but no `packages/omega-sieve/` files were present in this checkout. Do not make it a runtime dependency without revalidation.

## 3. The Doctrine: Collection Is a State Machine

A collector must move material through explicit states. A URL is not a document until its source and rights are known.

```text
DISCOVER
  ↓
POLICY_CHECKED
  ↓
FETCHED
  ↓
EXTRACTED
  ↓
HASHED
  ↓
CLASSIFIED
  ↓
QUARANTINED
  ↓
EVALUATED
  ↓
PROMOTED / REJECTED / RETRY / EXPIRED
```

### 3.1 `DISCOVER`

Record:

- collector name/version;
- discovery query and source class;
- canonical landing URL, not only a transient download URL;
- source policy URL and retrieval date;
- API/catalog endpoint or feed path;
- requested identifier and returned identifiers;
- no content body yet.

### 3.2 `POLICY_CHECKED`

Before fetching, record:

- `robots_txt_checked: true|false|not_applicable`;
- `terms_url`;
- `access_pattern`: API, feed, dump, OAI, single-file, human-page exception;
- `rate_limit_observed`;
- `rights_class`: metadata-only, abstract-only, public-domain, open-license, restricted, unknown;
- `operator_or_policy_approver`.

Unknown rights cannot become a shareable seed. It may remain in a local quarantine with access restricted to the operator.

### 3.3 `FETCHED` and `EXTRACTED`

Use the least expensive lawful extractor that can satisfy the task:

1. **T1**: static HTML and ordinary article/book pages;
2. **T2**: known source structure, markers, tables, or metadata boundaries;
3. **T3**: JavaScript-rendered or structurally difficult pages, only when necessary and allowed.

The current T3 Crawl4AI design is a good local-first foundation. Crawl4AI's Apache-2.0 license covers the software; it does not grant rights to the pages or files being extracted. [W1]

Do not use stealth, CAPTCHA bypass, login simulation, cookie replay, or browser fingerprint evasion to circumvent a source's access policy. If a source requires an account or has no lawful automated path, use its official export/API or stop.

## 4. Politeness and Access Controls

1. Send a descriptive User-Agent with tool name, version, contact URL/email, and (where required) model identity.
2. Use official bulk feeds, dumps, OAI, or batch endpoints for bulk instead of thousands of individual requests.
3. Serialize requests unless the source explicitly documents safe concurrency.
4. Cache immutable responses and content by hash. Do not repeatedly fetch the same page.
5. Honor `Retry-After`, `429`, robots directives, source-specific throttles, and terms.
6. Limit deep crawling by page count, depth, and total bytes. Never recursively crawl an entire site by default.
7. Do not use a source's human-facing site as a high-volume API.
8. Log every fetch: URL, timestamp, status, bytes, content hash, collector version, and reason.
9. If a source changes its policy or returns `401`, `403`, `429`, or a block page, stop or slow down. Do not route around it.

## 5. Extraction and Provenance Requirements

Each extracted item must carry:

```yaml
collector: "n1-collector"
collector_version: "0.1.0"
source_uri: "https://canonical.example/item"
retrieval_uri: "https://download.example/file"
retrieved_at: "2026-09-25T00:00:00Z"
http_status: 200
content_type: "text/html; charset=utf-8"
content_sha256: "..."
extractor_tier: "T3"
extractor_config_sha256: "..."
title: "..."
authors: []
identifiers: {}
license: "..."
license_url: "..."
rights_jurisdiction: "..."
access_class: "metadata_only"
citation: "..."
parent_manifest: "..."
```

The Node 0 CAS is a strong local pattern: it hashes the bytes it stores. However, if only cleaned Markdown is stored, the hash proves the cleaned artifact, not the original server response. For high-value sources, preserve a permitted raw response or a signed response fingerprint. [A1]

## 6. Retry, Failure, and Degradation

| Failure | Default action |
|---|---|
| DNS/Temporary network error | Retry with exponential backoff + jitter; cap at 3 attempts. |
| HTTP 408/425/429/5xx | Honor `Retry-After`; exponential backoff; reduce concurrency; circuit-break after threshold. |
| HTTP 400/404/410 | Do not retry; record terminal state and reason. |
| HTTP 401/403 | Stop. Do not bypass. Escalate to official API/export/auth route. |
| Robots disallow / terms conflict | Quarantine or reject. Never crawl around it. |
| Empty extraction | Try T2/T3 only if policy permits; otherwise mark `EXTRACTION_EMPTY`. |
| T3 browser unavailable | Fall back to T1 only for static pages and record `tier_fallback`; never claim deep extraction succeeded. |
| Schema/parser failure | Preserve raw artifact if lawful, quarantine, and emit a typed failure. |
| Rights unknown | Keep local/quarantined; never promote to a public seed. |
| Duplicate content | Do not create a second canonical item; link the alternate source/accession. |

The existing worker already has a useful 3-retry delayed requeue pattern [L0]. It should be extended with typed terminal states, per-host circuit breakers, and a durable dead-letter manifest before autonomous collection.

## 7. Crawl4AI Operational Profile for Node 1

Recommended first profile:

- self-hosted open-source Crawl4AI, Apache-2.0 [W1];
- Playwright/Chromium only where JavaScript rendering is required;
- T1 for catalog/article/book HTML;
- T3 maximum 1 page per job initially, 30-second timeout;
- no stealth/evasion features;
- no LLM extraction of private material through a cloud route;
- no cookies or authenticated browser profiles in a shared collector;
- Markdown output stored with source URL, extraction timestamp, content hash, and config hash;
- raw source capture only when source policy permits.

The local Node 0 code's `CacheMode.BYPASS` is appropriate for a freshness test but is not a general caching policy. For repeated collection, use a cache keyed by URL, ETag/Last-Modified where available, and content hash. [A1]

## 8. Security Boundaries

- Secrets belong in a local secret manager, never manifests or prompts.
- Cloud LLM extraction is forbidden for `local_private` and `personal_restricted` classes.
- PII masking is defense-in-depth, not a rights grant.
- Never write a fetched page into an entity workspace before quarantine and manifest creation.
- Never place SQLite authority on NFS; Node 1's local SQLite remains authoritative for local state. [L1]
- MemPalace is a one-way searchable projection in the Node 0/Node 1 charter, not a second uncoordinated write authority. [L1]

## 9. Promotion Gate for Any Crawl4AI Result

A result may leave quarantine only when:

- the source policy and access pattern are recorded;
- the content class and rights status are explicit;
- a citation and stable accession are captured;
- the content hash is stored;
- duplicate checks pass;
- secrets/PII scan passes;
- extraction provenance is complete;
- a human or policy owner approves the class;
- the destination entity/domain is authorized;
- the item is included in a manifest and evaluation set.

## 10. Current Local Test Evidence

The existing `tests/test_e2e_sovereign_sieve.py` is useful smoke evidence, but it is not a legal or production readiness suite. It allows T3 failure when browser dependencies are missing. Node 1 should add a local, deterministic fixture suite before enabling live collection. [L0]

*⬡ OMEGA ⬡ ROC_RACOON ⬡ CRAWL4AI-DOCTRINE ⬡ 2026-09-25*