<!--
SPDX-FileCopyrightText: 2026 Xoe-NovAi
SPDX-License-Identifier: Apache-2.0
-->

# Node 1 Library MVP Blueprint

**Recommendation**: build a 120-item, five-domain, rights-labeled golden set before enabling autonomous collection.
**Target hardware reality**: Node 1 ASUS CPU-only, local-first, 16GB single-channel; local collection and indexing must remain bounded. [L1]

## 1. MVP Scope

### In scope

- lawful catalog and metadata collection;
- public-domain and open-license full text only after item-level rights review;
- read-only seed libraries for five initial Node 1 domains;
- local FTS5 and sqlite-vec projection;
- manifest, rights, citation, hash, deduplication, and evaluation records;
- Crawl4AI T1/T2/T3 use only under the doctrine in this package;
- local-only private evaluation holdout when the operator supplies it.

### Out of scope

- unrestricted web crawling;
- automatic download of copyrighted books or papers;
- cloud LLM extraction of private material;
- cross-node vector sharing before parity gates pass;
- direct writes into Node 0 Engine core;
- automatic promotion of discovered material;
- replacing MemPalace, The Well, or WanderGround with a new library.

## 2. Initial Corpus: 120 Public/Shareable Items

The golden set is deliberately mixed so retrieval quality cannot be inflated by one source family.

| Source class | Target items | Acquisition pattern |
|---|---:|---|
| `S0_PRIMARY_TEXT` public-domain/open public text | 30 | Project Gutenberg, Standard Ebooks, Wikisource where page rights permit |
| `S1_OPEN_LICENSE` named-license material | 30 | DOAB books, permitted arXiv e-prints, Europe PMC OA articles |
| `S2_CATALOG_METADATA` | 25 | Open Library, Internet Archive, HathiTrust, DOAB metadata |
| `S3_ABSTRACT_OR_INDEX` | 25 | Crossref, OpenAlex, Semantic Scholar, PubMed/Europe PMC |
| `S4_RESTRICTED_METADATA` rights-edge tests | 10 | HathiTrust/publisher metadata with no full-text promotion |
| **Total** | **120** | No personal/private material in the shareable golden set |

This is a target, not permission to force a source class. If a source cannot supply a lawful item, leave the slot empty and document why; never fill it with an unlicensed substitute.

### 2.1 Five-domain allocation

Use 24 items per initial domain:

| Domain | 24-item emphasis | Likely source mix |
|---|---|---|
| `local_ai` | inference, retrieval, CPU runtimes, MCP, agent systems | arXiv/OpenAlex/Crossref, official docs, open technical reports |
| `consciousness_time` | philosophy of mind, time, ontology, phenomenology | books/catalog metadata, scholarly abstracts, Wikisource where appropriate |
| `classical_studies` | primary texts, ancient science, mythology, translations | Wikisource, Standard Ebooks, public-domain editions, DOAB scholarly books |
| `deep_psychology` | Jung, phenomenology, existentialism, archetypes | public-domain books, scholarly metadata, open licensed studies |
| `video_games` | game design, simulation, engine architecture, space sims | technical sources, open books/articles, archival/catalog records |

Each domain must include:

- at least 5 `S0`/`S1` full-text items;
- at least 8 metadata/abstract items;
- at least 2 items with a known contradiction or version relationship;
- at least 1 source that must be rights-restricted or metadata-only;
- no more than 40% of the domain from one source family.

## 3. Phase Plan

### Phase 0 — Manifest and Policy Shell

**Deliverables**:

- seed manifest schema;
- rights-class enum and review checklist;
- source policy registry;
- stable ID and SHA-256 manifest writer;
- private/public destination flags;
- 50-query evaluation set skeleton.

**Exit gate**: no collector can write directly to an entity KB. All output goes to `quarantine/`.

### Phase 1 — 20-Item Pilot

Select four items per domain. Include:

- two Project Gutenberg/Standard Ebooks/Wikisource public-domain records;
- two DOAB or other open-license book records;
- four scholarly metadata/abstract records;
- two restricted-metadata records;
- two version/contradiction pairs.

Run the existing pattern conceptually and locally:

1. metadata/catalog lookup;
2. policy check;
3. T1 extraction;
4. T3 only where needed;
5. SHA-256;
6. citation/manifest;
7. quarantine;
8. manual rights and relevance review.

**Exit gate**: 100% of items have source, rights status, accession/citation, hash, and quarantine state. Zero unknown rights are promoted.

### Phase 2 — 60-Item Corpus

Expand to 12 items per domain. Add:

- Crossref/OpenAlex/Semantic Scholar metadata triangulation;
- PubMed/Europe PMC only for relevant domains or a dedicated biomedical mini-domain;
- HathiTrust rights metadata;
- Internet Archive item metadata;
- duplicate and edition-relationship tests.

**Exit gate**: exact duplicate handling, citation integrity, and rights classification meet the thresholds in §6.

### Phase 3 — 120-Item Golden Set

Complete the public/shareable set. Freeze a versioned snapshot:

```text
golden-set-v1/
  manifest.yaml
  SHA256SUMS
  rights/
  items/
  queries/
  evaluations/
  known-contradictions.yaml
```

Do not silently edit a frozen item. Add a new version and record the reason.

### Phase 4 — Read-only Seed Projection

Build entity/domain seed libraries and local projections:

- FTS5 index;
- sqlite-vec index with pinned model/dimension/preprocessing;
- optional MemPalace projection;
- optional WanderGround Atlas projection;
- The Well reserved for approved operating rules, not book storage.

**Exit gate**: deleting/rebuilding a derived index does not change the seed. Every retrieval result returns source ID and citation.

### Phase 5 — Federation/Embedding Parity

Only after the seed is stable:

- exchange manifests and hashes;
- verify rights and privacy;
- compare Node 0/Node 1 embedding outputs on 50 shared queries;
- compare top-k and score thresholds;
- keep FTS/metadata evaluation independent.

## 4. Collector Pipeline

```text
source registry
    ↓
catalog/API/feed collector
    ↓
rights + policy gate
    ↓
T1 fast extraction
    ↓
T2 surgical extraction (when source-specific)
    ↓
T3 Crawl4AI (only when necessary/allowed)
    ↓
normalizer + citation capture
    ↓
SHA-256 + stable identity
    ↓
dedupe/relationship resolver
    ↓
quarantine
    ↓
quality/contradiction evaluation
    ↓
operator promotion
    ↓
read-only seed
    ↓
FTS5 / sqlite-vec / MemPalace projection
```

### Collector rules

- one source adapter per provider family;
- source adapters return a common `SourceRecord` manifest;
- no provider-specific fields leak into entity prompts;
- no direct entity write;
- every request logs User-Agent, source policy, timestamp, and outcome;
- every content write is atomic;
- no background worker may bypass quarantine;
- dead-letter records are durable and inspectable.

## 5. Manifest Minimum

```yaml
schema_version: "1.0"
seed_id: node1-golden-v1
created_at: "2026-09-25T00:00:00Z"
operator: "Node 1 operator"
domains: [local_ai, consciousness_time, classical_studies, deep_psychology, video_games]
source_policy_checked_at: "2026-09-25T00:00:00Z"
items:
  - item_id: "pg-1342"
    source_class: S0_PRIMARY_TEXT
    source_family: project_gutenberg
    source_uri: "https://www.gutenberg.org/ebooks/1342"
    accession: "gutenberg:1342"
    title: "Pride and Prejudice"
    creators: ["Jane Austen"]
    dates: {source_edition: null, gutenberg_release: "1994-01-01"}
    rights:
      status: "public_domain_or_pg_license"
      license: "Project Gutenberg License / US public-domain notice"
      license_url: "https://www.gutenberg.org/policy/permission.html"
      jurisdiction: "US"
      checked_at: "2026-09-25"
    content:
      included: true
      path: "items/pg-1342/content.txt"
      sha256: "..."
    citation: "Austen, Jane. Pride and Prejudice. Project Gutenberg."
    collector: "n1-catalog-v0.1.0"
    status: "quarantined"
    operator_approval: false
```

## 6. Acceptance Metrics and Gates

### Collection and provenance

| Metric | MVP gate |
|---|---:|
| Items with canonical source URI | 100% |
| Items with accession or stable local ID | 100% |
| Items with retrieval timestamp | 100% |
| Items with SHA-256 | 100% |
| Items with citation | 100% |
| Items with rights status | 100% |
| Items with unknown rights promoted | 0 |
| Items with source policy URL/exception reason | 100% |
| Secret/PII leakage | 0 |

### Deduplication and relationships

| Metric | MVP gate |
|---|---:|
| Exact DOI/ISBN/arXiv duplicate precision | 100% on labeled test set |
| Near-duplicate recall on seeded pairs | ≥ 0.90 |
| Edition/version lineage recorded | 100% of detected pairs |
| Wrongly merged distinct editions | 0 |

### Retrieval and evidence

| Metric | MVP gate |
|---|---:|
| Golden query Recall@10 | ≥ 0.80 on FTS baseline |
| Golden query nDCG@10 | Report; target ≥ 0.75 |
| Citation pointer resolution | 100% |
| Unsupported claim rate in derived summaries | ≤ 2% on human review sample |
| Contradiction detection precision | ≥ 0.80 on seeded cases |
| Abstention when evidence insufficient | 100% on explicit holdout |

### Operational stability

| Metric | MVP gate |
|---|---:|
| T1 success on permitted static pages | ≥ 0.95 |
| T3 fallback correctly labeled | 100% |
| Retry exhaustion produces terminal manifest | 100% |
| Duplicate fetch avoided by cache/hash | ≥ 0.90 on repeat test |
| No direct unquarantined writes | 0 |

## 7. Promotion Gates

1. **P0 — Source safety**: official source, policy, access pattern, and rate limit recorded.
2. **P1 — Provenance**: canonical URL, accession, timestamp, collector/version, content hash, citation.
3. **P2 — Rights/privacy**: license/rights URL, jurisdiction, access class, no secret/PII, destination boundary.
4. **P3 — Quality**: relevance profile, completeness, trust, duplicates, contradictions.
5. **P4 — Entity authorization**: curator/operator approves entity/domain and access level.
6. **P5 — Projection**: read-only seed generated; FTS/vector index is rebuildable; retrieval cites source.
7. **P6 — Federation**: hash/manifest/privacy checks pass; no private material; no automatic constitutional merge.

A failed gate is a typed state, not a warning that gets ignored.

## 8. Risks and Mitigations

| Risk | Mitigation |
|---|---|
| Catalog metadata mistaken for content permission | Rights class and per-item license gate |
| Source changes terms or API behavior | Store terms URL/date; revalidate before scale |
| Crawl4AI software license confused with content rights | Separate software and source rights in manifest |
| T3 browser unavailable | T1 fallback, explicit `tier_fallback`, no deep claim |
| Duplicate mirrors inflate evidence | independence groups and claim-level provenance |
| Random UUIDs prevent stable dedupe | stable accession + content hash + relationship table |
| Node 0/Node 1 vector spaces differ | 50-query parity gate; metadata/FTS fallback |
| Private material enters a shared seed | quarantine + privacy scan + explicit destination class |
| The Well becomes an unreviewed dumping ground | Well stores approved rules; source bodies remain in seed layers |
| MemPalace becomes a second authority | one-way projection and local SQLite authority |
| Node 0 Engine core grows domain-specific crawler code | WAD/domain adapters and read-only library boundary |

## 9. Definition of Done for Node 1 MVP

- [ ] 20-item pilot passes P0–P3.
- [ ] 60-item corpus passes duplicate/citation/rights metrics.
- [ ] 120-item golden set is frozen with manifest and SHA-256 sums.
- [ ] Five domain seed libraries exist as read-only packages.
- [ ] FTS5 retrieval baseline and 50-query evaluation are published.
- [ ] Optional sqlite-vec projection is pinned and reproducible.
- [ ] MemPalace/WanderGround projections, if used, are one-way and rebuildable.
- [ ] No personal/private material is present in the shareable package.
- [ ] Cross-node vector parity is either proven or explicitly deferred.
- [ ] Operator signs the promotion manifest.
- [ ] A rollback/rebuild drill succeeds.

## 10. Immediate Next Action for Node 1

Start with a manifest-only pilot, not a crawler:

1. choose the five domain names and owners;
2. collect 20 candidate items (four per domain) from official APIs/feeds;
3. record rights and access paths before downloading content;
4. create a frozen `golden-pilot-v0` package;
5. run FTS/metadata evaluation;
6. request operator review;
7. only then enable Crawl4AI T3 for the few items that need it.

*⬡ OMEGA ⬡ ROC_RACOON ⬡ NODE1-LIBRARY-MVP ⬡ 2026-09-25*