<!--
SPDX-FileCopyrightText: 2026 Xoe-NovAi
SPDX-License-Identifier: Apache-2.0
-->

# Per-Entity Curated Knowledge-Base Architecture

**Scope**: Node 1's entity/domain knowledge layer and its safe relationship to the Node 0 Omega Engine.
**Status**: Architecture recommendation grounded in local and Node 1-received evidence.

## 1. Layer Map

```text
                    ┌──────────────────────────────────────────┐
                    │ Entity / Domain Profile                 │
                    │ purpose, topics, source weights, access │
                    └──────────────────┬───────────────────────┘
                                       ↓
                    ┌──────────────────────────────────────────┐
                    │ Read-only Seed Libraries                │
                    │ manifests + permitted content + hashes │
                    └──────────────────┬───────────────────────┘
                                       ↓
                    ┌──────────────────────────────────────────┐
                    │ Node 1 Local Curation Plane            │
                    │ WanderGround / Well / MemPalace / Atlas│
                    └──────────────┬──────────────┬───────────┘
                                   ↓              ↓
                    ┌────────────────────┐  ┌────────────────────┐
                    │ Local retrieval    │  │ Derived research   │
                    │ FTS5/sqlite-vec    │  │ claims, summaries  │
                    └─────────┬──────────┘  └─────────┬──────────┘
                              ↓                         ↓
                    ┌──────────────────────────────────────────┐
                    │ Entity consumption + citations          │
                    │ no direct Engine-core mutation          │
                    └──────────────────────────────────────────┘
```

The Node 0 Engine is a runtime and shared substrate. Entity knowledge is a WAD/domain/realm concern. [L1][A1]

## 2. Canonical Node 1 Components

### 2.1 WanderGround — capture and local exploration

Node 1 received material reports a local `~/WanderGround/` with:

- frictionless capture inbox and `wander` CLI;
- five domain folders;
- local Knowledge Atlas using sqlite-vec;
- curator service/timer;
- 3D projection/viewer;
- dossiers and local encyclopedia. [L1]

Use it as the **local exploration and staging plane**, not as a public distribution service. Raw captures remain append-only until curation.

### 2.2 The Well — active rules and corrections

The Well is reported as an append-only record store with capture, active/superseded lifecycle, export, and injection into local session/compaction context. [L1]

Use The Well for:

- agent operating rules;
- corrections and failed assumptions;
- domain-specific preferences;
- high-confidence lessons that are meant to affect behavior.

Do not use The Well as a substitute for a book/article library. It is not a full-text archive and should not contain copyrighted source bodies.

### 2.3 MemPalace — searchable projection

MemPalace v3.9.0 is reported live with 42 MCP tools, 62 drawers, and provenance-preserving search. [L1]

Use MemPalace for:

- local, searchable projections of approved material;
- drawers/rooms/wings and relationships;
- retrieval experiments;
- compact, entity-oriented views.

The federation charter says MemPalace is a **one-way searchable projection**, not a second uncoordinated write authority. [L1] Node 0 source material remains in the local Node 0 CAS/anchors; Node 1 MemPalace receives only promoted, authorized projections.

### 2.4 Omega Engine library/indexer

Node 0 has a real `src/omega/library/` path with `CuratedDocument`, FTS5 indexing, and vector adapter integration. [L0]

Use the Engine library as a **read-only consumer boundary** for Node 1 seeds. Do not make Node 1's private collection, raw browser data, or personal archive a hidden dependency of Engine core.

The current `domain_loader.py` is marked **PLANNED** in the curator charter. Do not claim runtime domain enforcement until the loader exists and is tested. [L0]

## 3. Entity Domain Profile

Each entity or domain receives a versioned profile:

```yaml
schema_version: "1.0"
profile_id: local_ai
entity: researcher
domain: local_ai
purpose: "Sovereign local inference, retrieval, and engine operations"
curator: researcher
governance: SHARED_READ
allowed_source_classes:
  - S0_PRIMARY_TEXT
  - S1_OPEN_LICENSE
  - S2_CATALOG_METADATA
  - S3_ABSTRACT_OR_INDEX
forbidden_without_explicit_approval:
  - S5_LOCAL_PRIVATE
  - full_text_restricted
retention:
  public_seed: indefinite_with_terms_recheck
  local_private: local_only
citation_required: true
embedding:
  model: "pin-before-use"
  dimensions: 768
  preprocessing_hash: "required"
paths:
  seeds: "data/entities/researcher/knowledge/seeds"
  proposals: "data/entities/researcher/knowledge/proposals"
  local_private: "data/entities/researcher/private"   # never in shared seed
```

Profiles are policy, not content. A profile may change only through a reviewable manifest and operator approval.

## 4. Knowledge Layers

### Layer 0 — Raw local capture

Append-only inbox, personal/private by default. Never read by a shared entity without an explicit policy.

### Layer 1 — Quarantine

Collector output with source URL, rights status, content hash, and extraction provenance. Searchable by the curator, not automatically by all entities.

### Layer 2 — Read-only seed library

Stable, versioned, entity/domain-authorized corpus. Contains metadata, permitted content, citations, rights files, and hashes. The entity cannot mutate it.

### Layer 3 — Local derived projection

FTS5/sqlite-vec/MemPalace/WanderGround indexes and generated summaries. Rebuildable from Layer 2. It is not the canonical source of truth.

### Layer 4 — Entity working context

A bounded retrieval bundle assembled for a task. Must carry citations and source IDs; it is ephemeral and cannot become an untracked training corpus.

### Layer 5 — Approved lessons/promotions

Only operator-approved claims or principles enter the Well/approved lessons system. This is a different mint from external books and articles.

## 5. Read-only Seed Contract

A seed package is immutable and portable:

```text
seed-library/
  manifest.yaml
  SHA256SUMS
  rights-policy.yaml
  items/
    <item-id>/
      metadata.yaml
      citation.yaml
      rights.yaml
      content.ext       # only if permitted
  queries/
  evaluations/
  provenance/
```

Required manifest fields:

- seed version and creation time;
- creator and collector versions;
- source URLs and accessions;
- source class and exact license/rights URL;
- jurisdiction and rights-check date;
- content hash for every content file;
- parent/alternate relationships;
- public/private/share-alike flags;
- destination entity/domain authorization;
- embedding model/dimension only if vectors are included;
- operator approval and rollback reference.

An entity consumes the seed through a read-only file or database connection. New material is a proposal, not an in-place mutation.

## 6. Ingestion Boundaries

### Allowed

- API/catalog metadata into quarantine;
- public-domain/open-license content into a rights-cleared seed;
- local personal material into local-private storage;
- derived summaries/cards that link to parents;
- read-only index rebuilds from an approved seed.

### Forbidden without explicit approval

- personal correspondence, browser history, cookies, or credentials;
- copyrighted full text from a restricted source;
- cloud LLM extraction of private material;
- direct writes from a remote entity into Engine core;
- sharing a local-private seed through federation/USB;
- treating a model summary as a primary source;
- changing an approved seed in place.

## 7. Portability and Federation

Use a two-phase transfer:

1. **Package** — manifest, hashes, rights, citations, and permitted files;
2. **Verify** — receiver verifies hash, schema, license, privacy, and manifest before indexing.

The Node 1 reconnection protocol describes quarantine-first staging and human conflict escalation. [L1] Apply the same pattern to knowledge domains:

```text
PACK → SHA256 VERIFY → RIGHTS REVIEW → PRIVACY REVIEW → QUARANTINE
     → EVALUATE → OPERATOR PROMOTE → LOCAL INDEX
```

No automatic merge of constitutional or policy material. No bidirectional write authority. Local SQLite remains authoritative on its own node. [L1]

## 8. Embedding Compatibility Gate

Cross-node semantic retrieval is not proven merely because both sides say “Qwen” or both use 768 dimensions.

Before sharing vectors or comparing scores, verify:

1. exact model artifact and version;
2. exact dimension and distance metric;
3. normalization and pooling;
4. instruction/prompt template;
5. truncation and context policy;
6. preprocessing and text cleaning;
7. golden-corpus embeddings and cosine parity;
8. score/top-k parity on at least 50 shared queries;
9. rebuild path when the model changes.

Node 1 received material recommends Qwen3-Embedding-0.6B at 768 dimensions, but its WanderGround specification also describes Nomic 768-dimensional embeddings. [L1] Node 0's current library default is `omega_vec_qwen_768`. [L0] Therefore the MVP must keep **metadata/FTS evaluation independent of vector parity**, and vector federation remains blocked until the gate above passes.

## 9. Consumption Contract for Entities

An entity should receive a retrieval bundle such as:

```yaml
bundle_id: seed-2026-09-25-r01
entity: researcher
domain: research
source_seed: seed-library-v3
retrieved_at: "2026-09-25T00:00:00Z"
items:
  - item_id: doi:...
    title: "..."
    citation: "..."
    rights_class: S3_ABSTRACT_OR_INDEX
    excerpt_or_pointer: "..."
    content_sha256: "..."
    trust: 0.82
    freshness: "2026-09-01"
```

An entity may summarize, compare, and propose lessons. It must preserve the source pointer and must not rewrite the seed or claim access to restricted content.

## 10. Open Questions for Node 1

1. Which five domain profiles are final for the first MVP?
2. Is MemPalace the only local projection, or should WanderGround Atlas and MemPalace have separate read-only roles?
3. What is the canonical source for personal/private material?
4. Which embedding model is actually running now, and what is its exact preprocessing hash?
5. Who approves public seed promotion: Node 1 operator, domain curator, or both?
6. Which Node 1 entities may read each domain seed?
7. What retention period applies to local-private material?
8. Which sources are approved for a future USB package?

## 11. Non-Claims

Until measured evidence exists, do not claim:

- a runtime `domain_loader.py` enforcement path;
- automatic rights clearance;
- full text is available from every catalog record;
- MemPalace and Node 0 Engine are one shared write authority;
- vectors are semantically compatible across nodes;
- The Well is a full-text library;
- a local private seed is safe to federate.

*⬡ OMEGA ⬡ ROC_RACOON ⬡ PER-ENTITY-KB-ARCHITECTURE ⬡ 2026-09-25*