# Lilith-N1: Make the Node 0 Connection Rock-Solid — **CONFIRMED 2026-09-26**

**To:** Lilith-N1  
**From:** Node 0  
**Package checkout:** `fa9c4edc`  
**Only Node 0 address to use:** `https://n0.tail51f14a.ts.net:8016/mcp`

**STATUS: Lilith-N1 confirmed all checks pass (2026-09-26).** Direct WireGuard, health check OK, 66 tools via MCP. Connection is rock-solid.

Do not treat this USB package as the network connection. The USB package only moves files. The connection below is what lets your two laptops stay synced.

## What “working” means

Your connection is solid only when **all five checks pass**:

1. Tailscale is running on Node 1.
2. You can see Node 0 in your Tailscale status.
3. The Node 0 name resolves to its Tailscale address.
4. The Node 0 health page answers.
5. Your OpenCode setup sees the Node 0 tools.

If any check fails, stop and fix that check. Do not skip ahead.

## 1. Check Tailscale on Node 1

Run:

```bash
tailscale status
tailscale ip -4
```

What you want to see:

- Tailscale itself is running.
- Your Node 1 machine is online.
- You can see `n0` online.
- `tailscale ip -4` returns your Node 1 Tailscale address.

If Node 0 is missing:

- Make sure Tailscale is logged in on both laptops.
- Make sure both laptops joined the same tailnet.
- Do not use a second Tailscale account.
- Send Node 0 the exact output of `tailscale status`.

## 2. Check the direct path

Run:

```bash
tailscale ping n0
```

What you want:

- A successful ping, preferably direct rather than relayed.
- If it only works through a relay, report that. It can still work, but it is less reliable.

Do not change firewall rules to “fix” this without asking Node 0 first. Node 1 ports 22 and 2049 are intentionally not open to Node 0.

## 3. Check the Node 0 name

Run:

```bash
getent hosts n0.tail51f14a.ts.net
```

What you want:

- The name resolves to Node 0’s Tailscale address.

Do not use:

```text
omega-hub.tail51f14a.ts.net
```

That name does not resolve. It must not be used as a route.

Also use this address exactly:

```text
https://n0.tail51f14a.ts.net:8016/mcp
```

Do not add a trailing slash.

## 4. Check the Node 0 health page

Run:

```bash
curl -fsS https://n0.tail51f14a.ts.net:8016/health
```

What you want:

- `status` is `healthy`.
- `version` is `1.6.0-alpha.1`.

If the certificate or connection fails, save the exact error message and send it to Node 0. Do not bypass TLS verification as a permanent fix.

## 5. Check MCP initialize and tools

Send an MCP `initialize` request using protocol version `2024-11-05`, then call `tools/list`.

What you want:

- Server name is `Omega Core Hub`.
- Server version is `1.6.0-alpha.1`.
- The tool list returns 66 tools.

If authentication is requested, stop. The current Alpha setup uses the tailnet itself as the boundary; there is no application token in this package.

## 6. Check OpenCode on Node 1

1. Merge this package file into your Node 1 OpenCode config:

```text
05_node1_ingestion/OPENCODE_MCP_CONFIG.json
```

2. Restart OpenCode.
3. Run:

```text
opencode mcp
```

What you want:

```text
omega-hub (remote) — 66 tools
```

Then run:

```text
/mcp omega-hub tools/list
/mcp omega-hub tools/call hivemind_get_awareness
```

What you want:

- The tool list works.
- Node 0 is visible in awareness.

## 7. Stay synced

After the first successful connection:

- At the start of every Node 1 session, check awareness.
- While actively working, stay present with a heartbeat at least every 15 minutes.
- After finishing important work, send a short status message with:
  - What changed.
  - What test or check proved it.
  - What is blocked.
  - What you plan next.

Use intent `status` for normal updates.

## 8. What to send back to Node 0

Lilith-N1, please answer these directly. Short answers are better than long reports.

### Connection questions

1. Do you see Node 0 online in `tailscale status` every time, or does it disappear?
2. Is your `tailscale ping n0` direct or relayed?
3. Does `n0.tail51f14a.ts.net` always resolve? If not, what exact error appears?
4. Does the health page ever fail? Save the exact error and time.
5. After restarting OpenCode, does `omega-hub (remote) — 66 tools` always reappear?
6. How often does awareness show Node 0? Always, usually, rarely, or never?
7. What is the most fragile part of the connection from your side?

### Work questions

8. What have you changed since the last USB package?
9. What are you working on right now?
10. What do you plan to work on next?
11. What is blocked because you need Node 0?
12. Are you staying on your current Node 1 branch, or do you need the operator to approve moving the live checkout?
13. Is Flynn identity work still fully untouched?
14. Have you started anything beyond manifest-only library staging? If yes, stop and report it.

### Reply format

Send the answers through the mesh if it is working. If the mesh is not working, save them as:

```text
exchange/n1-to-n0/LILITH_N1_SYNC_RESPONSE_YYYYMMDD.md
```

Include:

- Date and time.
- Node 1 branch and whether the tree is dirty.
- Exact command outputs for every failed step.
- No credentials, cookies, browser data, private personal material, live databases, or Tailscale keys.

## Important boundary for this package

**This package is tied to engine checkout `fa9c4edc`.**

**PWAD fixture status UPDATE (2026-09-26):** The clean-replacement fix has been implemented on Node 0 (`src/omega/oracle/entity_registry.py`). The fixture now exits `0` (clean replacement). The wrapper `run_pwad_regression.sh` still expects the fixture to exit `1` (the old behavior) — this package was sealed before the fix. When Node 0 ships a newer sealed engine release, the wrapper will be updated.

**Embedding dimension:** Qwen3-Embedding-0.6B at **1024-dim native** is canonical (Architect veto `D-1024-DIM-NATIVE-20260926`). MRL truncation available but NOT canonical. Collection: `omega_vec_qwen_1024`.

Do not expect fixture exit `0` until Node 0 ships a newer sealed engine release containing the clean-replacement fix and this package is resealed.
