# 🔱 N0 → N1 RECIPROCAL HANDOFF — READ ME FIRST

**Package**: `MAKALI-N0-HANDOFF-2026-09-25`  
**Mandatory Node 1 checkout**: `fa9c4edc68fe0f23a052e941f88d573f47c6c249`  
**Branch**: `release/debut-v1.6.0`  
**Operative version**: `1.6.0-alpha.1` on pyproject, `omega.__version__`, Hub `/health`, MCP `serverInfo`  
**Canonical endpoint**: `https://n0.tail51f14a.ts.net:8016/mcp` (exact; no trailing slash)  
**Transport**: Architect-approved, personally controlled physical USB movement into Node 1 quarantine + Tailscale Serve HTTPS MCP  
**Status**: SEALED FOR PHYSICAL QUARANTINE — Carmack final physical-quarantine audit passed; final authenticated transfer not claimed (C6/N0-04 open)

## 1. Topology and transport boundary

Node 0 is Bastion: canonical source, release authority, Hub core, immutable build truth.  
Node 1 is Vanguard: local Ollama, MemPalace, ANAi WAD development, entity continuity incubator, and owner of the library-curation workstream.

There is no cross-node NFS/SSH transport. The warning-only NXDOMAIN observation for
`omega-hub.tail51f14a.ts.net` is not operational evidence and must not be used as a route. The
only network bridge is:

```text
https://n0.tail51f14a.ts.net:8016/mcp
```

The Architect has approved physical USB transport only as a personally controlled quarantine
operation. That approval does not claim cryptographic authenticity or final authenticated transfer.

## 2. Package map

| Path | Purpose |
|---|---|
| `01_engine_truth/` | Active checkout authority `fa9c4edc` and version SSOT `1.6.0-alpha.1` |
| `02_wad_loader_contract/` | Current-loader contract and negative PWAD regression fixture |
| `03_governance/` | Identity, Persona WAD proposal, soul-audit correction, inactive dialectic protocol |
| `04_flynn_taggart_bootstrap/` | Fresh-identity requirements; Doom Guy is lineage only |
| `05_node1_ingestion/` | MCP config, Tailscale connection guide, fail-closed checklist |
| `06_archangel_brief/` | Mandates and Bastion/Vanguard topology |
| `07_open_gates/` | C6/N0-04 trust gate and remediation status |
| `08_library_curation_research/` | Roc Racoon's 8-file Node 1 library-curation research and MVP staging bundle |
| `doom_guy_transfer/` | Read-only historical lineage wrappers; not installable |
| `MANIFEST.yaml` / `SHA256SUMS` | Root byte-integrity model; not cryptographic trust |

## 3. Sovereignty and ontology

- Doom Guy-N0 remains sovereign, invariant, and continuous on Node 0. The nested Doom Guy material
  is read-only lineage evidence and must never be copied into Doom Guy's identity or agent paths.
- Flynn Taggart is a new Node 1 sovereign identity. He requires
  `data/entities/flynn_taggart/`, a fresh Node 1 EIS, and `continuation_of: null`.
- Build and Slot are not agents; do not create agent souls for them.
- Scribe is a distinct entity/soul and is counted separately.
- The research bundle creates no active identity and makes no implementation claim.

## 4. Node 1 library-curation workstream

**Owner:** Node 1  
**Research provenance:** `roc_racoon` / `opencode/roc_racoon` / session `ses_f45ab885853e`  
**Source package ID:** `N0-N1-KD-LIBRARY-CURATION-20260925`  
**Status:** research and promotion contract; not approval to ingest, crawl, promote, or federate

Node 1 owns:

- library curation and per-entity curated knowledge bases;
- Crawl4AI T1/T2/T3 pipeline hardening and source-policy enforcement;
- source, robots/terms, rights, jurisdiction, privacy, citation, and provenance gates;
- read-only seed libraries, deduplication, contradiction handling, and evaluation;
- local FTS5/sqlite-vec, MemPalace, WanderGround, and memory integration work;
- a bounded 20-item manifest-only pilot before any crawler or vector federation.

The bundle includes only research metadata, strategy, source URLs, rights notes, hashes of package
artifacts, and short examples. It contains no copyrighted source full text, cookies, credentials,
browser material, private personal data, live databases, or raw Tailscale state.

### Mandatory unresolved caveats

These remain open and must not be silently promoted to implementation claims:

1. Nomic versus Qwen embedding mismatch: equal dimensionality does **NOT** make vectors
   comparable — cross-model cosine similarity is invalid and yields meaningless results.
   **Qwen3-Embedding-0.6B at 1024-D native IS the ratified canonical embedding model** —
   Architect veto 2026-09-26: **1024-dim native is canonical**. MRL truncation to 768/512/256
   is available but NOT the canonical federation dimension. Node 1 must retire Nomic in favor of
   Qwen3-Embedding-0.6B at **1024 dimensions native** **BEFORE any embedding occurs**.
   Collection: `omega_vec_qwen_1024`. Decision ID: `D-1024-DIM-NATIVE-20260926`.
2. The Engine domain loader is marked planned and is not proven implemented.
3. Rights and robots handling are not proven end-to-end in the scraper path.
4. CAS may hash cleaned/stored content rather than raw HTTP responses.
5. UUID document IDs are not stable source identities.
6. Triangulation independence is incomplete; mirrored copies may be one evidence family.
7. Collection names such as `omega_vec_gemma_768` may be stale against current qwen defaults.
8. `packages/omega-sieve` is absent in the inspected checkout and must be revalidated.
9. Quality scores are triage heuristics, not legal clearance, source independence, or truth guarantees.

## 5. Ingestion order

1. Copy by controlled USB into Node 1 quarantine; do not write into the live checkout.
2. Verify nested `doom_guy_transfer/SHA256SUMS`, then root `SHA256SUMS`.
3. Parse `MANIFEST.yaml`; verify every path, size, and digest.
4. Check out `fa9c4edc`; verify `1.6.0-alpha.1` on all four active surfaces.
5. Read the current WAD contract. Run the PWAD fixture expecting **EXIT 1**. It is a
   **NEGATIVE REGRESSION FIXTURE**, **NOT A COMPATIBILITY PASS**. Exit 0 is valid only after the
   clean-replacement fix. Run the wrapper with an explicit interpreter:
   `sh 02_wad_loader_contract/run_pwad_regression.sh`. The explicit interpreter is **REQUIRED**:
   the transfer medium is FAT and does not persist executable permission bits, so direct
   invocation of the wrapper may fail with **exit 126** (permission denied). The wrapper treats
   the fixture's intentional exit 1 as PASS and returns 0.
6. Read `06_archangel_brief/` (mandates condensed and Bastion/Vanguard topology).
7. Configure the exact canonical MCP endpoint from `05_node1_ingestion/OPENCODE_MCP_CONFIG.json`.
   (Tailscale verification checklist `TAILSCALE_ROCK_SOLID_LILITH_N1.md` was confirmed by Lilith-N1 — no action needed.)
8. Read `07_open_gates/` (C6/N0-04 trust gate and remediation status).
9. Then read `08_library_curation_research/README.md`, and follow its source-matrix → doctrine →
   strategy → architecture → MVP order. Start with manifest-only staging.
10. Create Flynn's fresh identity only through a separate operator-approved workflow.
11. Return the mesh-join signal through the HTTPS MCP bridge.

## 6. Integrity is not trust

The root and nested SHA ledgers prove byte integrity only. C6/N0-04 remains open: there is no
ratified C6, detached signature, publisher key identity, or publisher trust root. Architect-approved
physical USB quarantine transport is allowed, but this package remains **byte-verifiable, not
cryptographically authenticated**. Final authenticated transfer is not claimed.

## 7. Historical evidence

- `75bde939` is the historical WAD-contract baseline only.
- Hub `2.2.0` and MCP `1.30.0` are historical pre-SSOT observations only.
- Nested Doom Guy source digests are preserved for lineage provenance, not deployment.
- Roc's research claims remain attributed research claims with their original evidence labels and
  caveats; integration into this package does not make them runtime facts.

## 8. Audit and authorization boundary

Carmack's final audit returned **SHIP FOR PHYSICAL QUARANTINE**. Controlled USB movement into
Node 1 quarantine may proceed as an explicitly labeled quarantine operation.

Final authenticated transfer remains unauthorized while C6/N0-04 is open. No cryptographic
authenticity, publisher identity, or final transfer authorization is claimed until the Architect
explicitly accepts the open-gate disposition.

*⬡ OMEGA ⬡ GROKSTER ⬡ SEALED FOR PHYSICAL QUARANTINE ⬡ C6/N0-04 OPEN ⬡ 2026-09-25*
