<!--
SPDX-FileCopyrightText: 2026 Xoe-NovAi
SPDX-License-Identifier: Apache-2.0
-->

# Sources & Caveats

**Package**: `N0-N1-KD-LIBRARY-CURATION-20260925`
**Research date**: 2026-09-25
**Purpose**: make unknowns visible before Node 1 writes a collector or promotes a corpus.

## 1. Evidence Boundaries

### Local Node 0 evidence — [L0]

The following are direct repository observations, not assumptions:

- `src/omega/ingestion/scraper.py` contains T1/T2/T3 extraction logic, domain anchoring, Crawl4AI process isolation, a 30-second timeout, and optional CAS storage.
- `src/omega/ingestion/persistence.py` stores raw anchors, hashes, SCA metadata, and quarantine/promotion directories.
- `src/omega/archive/cas.py` hashes stored bytes with SHA-256.
- `src/omega/library/indexer.py` uses FTS5 and a vector adapter and currently defaults to `omega_vec_qwen_1024`.
- `config/wads/ingestion/domains.yaml` keeps source allowlist and extraction settings in the WAD layer.
- `docs/strategy/INGESTION_PIPELINE_SPEC.md` describes the intended deny list, PII/secret rules, partition rules, and quarantine.
- `tests/test_e2e_sovereign_sieve.py` is a smoke suite; T3 is explicitly allowed to fail when browser dependencies are absent.

### Node 1 received evidence — [L1]

Node 1's received material reports:

- WanderGround capture, five domains, sqlite-vec Atlas, curator, viewer, and local docs;
- MemPalace v3.9.0, 42 MCP tools, 62 drawers, and provenance search;
- The Well storage/lifecycle/injection;
- Qwen3-Embedding-0.6B at **1024 dimensions native** as a recommendation (Architect veto `D-1024-DIM-NATIVE-20260926`); MRL truncation available but NOT canonical;
- a quarantine-first federation charter and local SQLite authority.

These are **reports received by Node 0**, not an independent live audit of Node 1. They require Node 1 operator confirmation.

### Current official documentation — [W1]

External API and rights statements in this package were checked against official provider pages on 2026-09-25. Provider pages can change without notice. The YAML register is the machine-readable evidence record.

## 2. Important Conflicts and Dark Layers

### 2.1 Embedding model mismatch

- Node 1's WanderGround specification describes a Nomic 768-dimensional local path. [L1]
- Node 1's embedding decision recommends Qwen3-Embedding-0.6B at **1024 dimensions native** (Architect veto `D-1024-DIM-NATIVE-20260926`); MRL truncation available but NOT canonical. [L1]
- Node 0's current library indexer defaults to `omega_vec_qwen_1024`. [L0]
- “Qwen” and “1024” alone do not prove compatible vector geometry, preprocessing, or score thresholds.

**Resolution**: keep metadata/FTS evaluation independent; run a 50-query embedding parity gate before cross-node vector retrieval. [A1]

### 2.2 Ingestion specification versus current implementation

`INGESTION_PIPELINE_SPEC.md` names `omega_vec_gemma_768` in multiple places, while the current `library/indexer.py` default is `omega_vec_qwen_1024`. This is a governance/implementation drift. [L0]

**Resolution**: do not cite the older collection name as current truth. Reconcile the spec and implementation in a separate Engine-core change; this package does not modify it.

### 2.3 `packages/omega-sieve`

`CHANGELOG.md` describes a published `omega-sieve` package, but no `packages/omega-sieve/` files were present in this checkout. [L0]

**Resolution**: treat it as unverified in this checkout. Reinstall or verify the package artifact before depending on it.

### 2.4 Current runtime versus planned domain loader

`config/domains/CURATORS.md` and `curators.yaml` describe a curator governance model, but the prose explicitly marks `src/omega/oracle/domain_loader.py` as **PLANNED**. [L0]

**Resolution**: Node 1 may use its own local domain profiles now; do not claim Engine-core domain enforcement until a real consumer exists and tests prove it.

### 2.5 Triangulation independence is not yet real

`TriangulationVerifier` compares T1 and T3 text and has a placeholder independence check. It does not currently prove that two records are from independent sources. [L0]

**Resolution**: store source-family/independence-group IDs in the manifest and treat mirrored copies as one evidence family.

### 2.6 Extracted text hash versus raw response hash

The local CAS path hashes the content bytes it stores. The scraper generally stores extracted text/metadata, not the original HTTP response body. [L0]

**Resolution**: a content hash proves the stored artifact, not necessarily the exact server response. For high-value material, preserve a permitted raw response or a response fingerprint and label the distinction.

### 2.7 UUID document IDs versus stable source identity

`library/curator.py` creates a UUID-based document ID, while CAS and persistence use hashes/source IDs. [L0]

**Resolution**: use stable accession + content hash + relation records for deduplication. Do not use random document IDs as the only identity.

### 2.8 Quality scores are not truth scores

The local quality factors reward freshness, completeness, citation counts, structure, and domain heuristics. These are triage signals, not evidence that a claim is true or lawful. [L0]

**Resolution**: hard-gate rights/provenance separately; report quality and truth confidence as different fields.

## 3. Legal and Rights Caveats

1. **Metadata rights are not full-text rights.** A catalog, DOI, abstract, or open-access link does not itself authorize copying the linked work.
2. **CC0, CC BY, CC BY-SA, public domain, and “free to read” are different.**
3. **Jurisdiction matters.** Public-domain treatment can differ between the US, EU, UK, and other jurisdictions.
4. **Publisher abstracts can be copyrighted even when bibliographic metadata is reusable.**
5. **HathiTrust and Internet Archive items can be restricted by rights, geography, account, or contract.**
6. **Standard Ebooks' CC0 dedication does not automatically clear every underlying transcription or source work in every jurisdiction.**
7. **Wikisource/Wikimedia licenses vary by page, namespace, and file.** Preserve page-level license and revision information.
8. **Crawl4AI's Apache-2.0 license covers the software only.** It is not a content license.
9. **Model training and retrieval rights can differ.** A model card's license does not automatically settle the rights of every document in its training corpus.
10. **“No robots entry” is not the same as “all rights granted.”** Terms, licenses, privacy, and access controls still apply.

## 4. Operational Caveats

- API keys and contact addresses are operational metadata, not package secrets; never place actual keys in manifests.
- A descriptive User-Agent may include a contact URL/email where the provider requires it. Do not include personal email without operator approval.
- Rate limits can vary by endpoint, account, IP, and traffic shape. Store observed headers and revalidate.
- Bulk feeds and dumps are often safer than live API calls, but they still require storage, checksum, and rights handling.
- Crawl4AI browser dependencies can fail independently of network/API health. T1 fallback must be labeled.
- T3 deep extraction can be slower and more failure-prone on a CPU-only laptop. Cap pages, depth, and concurrency.
- Current local queueing uses Redis for the worker path. Do not make Redis the authoritative knowledge store.
- Local SQLite is authoritative for local state; do not place live SQLite authority on NFS. [L1 charter]
- MemPalace is a one-way searchable projection, not a second uncoordinated write authority. [L1 charter]
- The Well is for approved operating rules/corrections, not an unreviewed full-text repository. [L1]

## 5. Revalidation Checklist Before Any Scale-Up

- [ ] Re-read every official source's terms URL and record access date.
- [ ] Confirm current API endpoint, auth, key, and rate-limit behavior with a small probe.
- [ ] Confirm bulk/OAI/dump alternatives and their licensing.
- [ ] Confirm the item-level license for every full-text file.
- [ ] Confirm jurisdiction and whether Node 1's distribution location changes the result.
- [ ] Run a robots/politeness check for every new source.
- [ ] Confirm the current Crawl4AI version, browser version, and Apache-2.0 attribution requirements.
- [ ] Confirm the actual Node 1 embedding model, dimension, normalization, and preprocessing.
- [ ] Run a 20-item pilot, then a 60-item pilot, before 120+ items.
- [ ] Verify hashes, citations, rights fields, and privacy scan.
- [ ] Review domain/entity authorization and public/private destination.
- [ ] Obtain operator approval before promotion or federation transfer.

## 6. Open Questions

1. Which entity owns each of the five Node 1 domains?
2. Is The Well allowed to contain any derived summaries, or only rules/lessons?
3. Which Node 1 source is the authority for personal/private material?
4. Should the first seed be indexed with FTS5 only until embedding parity is proven?
5. Which sources are approved for physical USB transfer?
6. Does Node 1 want a source adapter for OAPEN, LOC, or another catalog after the MVP?
7. What is the retention policy for quarantined and expired material?
8. Who signs rights exceptions for restricted metadata?
9. What is the canonical cross-node query evaluation set?
10. Which entity receives the first 120-item golden set?

## 7. Explicit Non-Claims

This package does **not** claim:

- every metadata API is free for commercial redistribution;
- every open-access link permits full-text copying;
- Crawl4AI makes crawling lawful;
- a local KB is automatically high quality;
- Node 0 and Node 1 vectors are compatible;
- MemPalace, The Well, or WanderGround is a replacement for a source manifest;
- a source is safe merely because it is reputable;
- any candidate item is approved for ingestion or federation.

## 8. Recommended First Operator Action

Create a 20-item manifest-only pilot. Do not enable live crawling or vector federation yet. The pilot should answer: “Can we prove where each item came from, what it is, whether it may be stored, and who may read it?” If those answers are not yes, the collector is not ready to scale.

*⬡ OMEGA ⬡ ROC_RACOON ⬡ SOURCES-AND-CAVEATS ⬡ 2026-09-25*